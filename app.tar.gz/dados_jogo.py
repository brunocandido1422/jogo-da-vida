import math
import random

# ==========================================
# ⚙️ CONFIGURAÇÕES GERAIS
# ==========================================
TOTAL_CASAS = 40
SALDO_INICIAL = 1621
PREMIOS_CHEGADA = [60000, 30000, 20000, 10000]

CORES_CASAS = [
    "#E53935", "#8E24AA", "#1E88E5", "#00897B", "#F4511E",
    "#6D4C41", "#039BE5", "#43A047", "#FB8C00", "#3949AB"
]

CORES_EQUIPES = [
    "#E53935", "#1E88E5", "#43A047", "#FB8C00",
    "#8E24AA", "#00897B", "#F4511E", "#3949AB"
]

DADO_FACES = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"]

# ==========================================
# ⚖️ DILEMAS FIXOS E EVENTOS
# ==========================================
DILEMAS_FIXOS = {
    1: {"titulo": "A mesada", "cenario": "Você recebeu sua mesada do mês. O que você faz?",
        "opcoes": [{"texto": "👗 Gasto tudo com roupas novas", "saldo": -150.00},
                   {"texto": "🍿 Uso metade com lazer e guardo o restante", "saldo": -75.00},
                   {"texto": "📚 Compro um livro novo", "saldo": -80.00, "livros": 1},
                   {"texto": "🐷 Guardo tudo para o futuro", "saldo": 150.00}]},
    2: {"titulo": "Material escolar", "cenario": "Início do ano chegou e com ele o momento de comprar cadernos. O que fazer?",
        "opcoes": [{"texto": "📓 Compro cadernos que são lançamentos", "saldo": -80.00},
                   {"texto": "📓 Compro cadernos em promoção", "saldo": -30.00}]},
    3: {"titulo": "Hora do lanche", "cenario": "Bateu uma fome na escola! Que tal um lanchinho entre as aulas?",
        "opcoes": [{"texto": "🍔 Compro um lanche na escola", "saldo": -20.00},
                   {"texto": "🤝 Compro um lanche dividido com um amigo", "saldo": -10.00},
                   {"texto": "🥪 Faço lanche em casa e levo para a escola", "saldo": -8.00},
                   {"texto": "🚫 Não lancho e fico com fome", "saldo": 0.00}]},
    6: {"titulo": "Passeio escolar", "cenario": "A escola organizou uma viagem para uma cidade histórica. O que você faz?",
        "opcoes": [{"texto": "🚌 Pago e viajo", "saldo": -150.00},
                   {"texto": "🏠 Fico em casa", "saldo": 0.00}]},
    7: {"titulo": "O tênis da moda", "cenario": "Teve o lançamento de um tênis desejado.",
        "opcoes": [{"texto": "👟 Compro agora", "saldo": -500.00},
                   {"texto": "🏷️ Espero entrar em promoção", "saldo": -350.00},
                   {"texto": "🥾 Compro um tênis mais barato", "saldo": -250.00},
                   {"texto": "👟 Uso o que tenho e economizo", "saldo": 0.00}]},
    8: {"titulo": "Roupa para festa", "cenario": "Uma festa do colegial está chegando.",
        "opcoes": [{"texto": "👗 Compro roupas novas", "saldo": -200.00},
                   {"texto": "👕 Uso as roupas que já tenho", "saldo": 0.00}]},
    9: {"titulo": "Cinema no final de semana", "cenario": "A turma toda vai ao cinema ver o filme indicado ao Oscar.",
        "opcoes": [{"texto": "🍿 Compro o ingresso, pipoca e refri", "saldo": -60.00},
                   {"texto": "🎟️ Compro somente o Ingresso", "saldo": -40.00},
                   {"texto": "🍔 Compro um lanche e não vou ao cinema", "saldo": -30.00},
                   {"texto": "🏠 Fico em casa", "saldo": 0.00}]},
    11: {"titulo": "Morar na república ou sozinho?", "cenario": "É hora de decidir onde morar durante o período da universidade.",
         "opcoes": [{"texto": "🏠 Vou morar em uma Kitnet sozinho", "saldo": -800.00},
                    {"texto": "👥 Vou dividir república", "saldo": -400.00},
                    {"texto": "😒 Vou alugar um quarto na casa de um tio desagradável", "saldo": -100.00},
                    {"texto": "🛏️ Vou morar em um alojamento", "saldo": 0.00}]},
    12: {"titulo": "Xerox ou original", "cenario": "O professor pediu um livro base importante para seu curso.",
         "opcoes": [{"texto": "📖 Compro o original", "saldo": -120.00, "livros": 1},
                    {"texto": "📄 Tiro um xerox", "saldo": -15.00},
                    {"texto": "🧠 Não preciso ler, já tenho conhecimento", "saldo": 0.00},
                    {"texto": "📚 Leio na biblioteca", "saldo": 0.00}]},
    13: {"titulo": "Congresso acadêmico", "cenario": "Terá um evento importante em outra cidade.",
         "opcoes": [{"texto": "🌟 Pago a inscrição com área VIP e viajo", "saldo": -750.00},
                    {"texto": "✈️ Pago a inscrição e viajo", "saldo": -500.00},
                    {"texto": "💻 Faço a inscrição para o evento online e assisto algumas palestras", "saldo": -200.00},
                    {"texto": "🚫 Não participo", "saldo": 0.00}]},
    14: {"titulo": "Festa ou prova", "cenario": "Você sabe que se divertir é importante e surgiu uma festa badalada na véspera de prova.",
         "opcoes": [{"texto": "👗 Vou à festa e compro roupa nova", "saldo": -250.00},
                    {"texto": "🎉 Vou à festa", "saldo": -100.00},
                    {"texto": "🎶 Vou à uma festa menos badalada", "saldo": -50.00},
                    {"texto": "📚 Fico em casa estudando", "saldo": 0.00}]},
    16: {"titulo": "O notebook quebrou", "cenario": "Seu computador pifou na semana de entrega de trabalhos importantes.",
         "opcoes": [{"texto": "💻 Compro um novo porque é mais rápido", "saldo": -2000.00},
                    {"texto": "🛠️ Mando arrumar", "saldo": -500.00},
                    {"texto": "🖥️ Alugo um tempo na Lan house", "saldo": -100.00},
                    {"texto": "🤝 Pego emprestado com um amigo", "saldo": 0.00}]},
    17: {"titulo": "Atrasado para a aula", "cenario": "Está chovendo muito no horário da aula.",
         "opcoes": [{"texto": "🚕 Vou de carro por aplicativo", "saldo": -30.00},
                    {"texto": "🤝 Divido o aplicativo de carro com um amigo", "saldo": -15.00},
                    {"texto": "🚌 Vou de ônibus", "saldo": -5.00},
                    {"texto": "☔ Encaro a chuva e vou a pé", "saldo": 0.00}]},
    18: {"titulo": "Oportunidade de estágio", "cenario": "Aprendizado ou dinheiro rápido?",
         "opcoes": [{"texto": "💼 Prefiro fazer freelancers", "saldo": 750.00},
                    {"texto": "🎓 Aceito o estágio acadêmico", "saldo": 500.00}]},
    19: {"titulo": "Lançou a Nova Temporada", "cenario": "Lançamento da nova temporada da sua série favorita.",
         "opcoes": [{"texto": "📺 Assino e pago sozinho", "saldo": -40.00},
                    {"texto": "🤝 Divido com os amigos", "saldo": -10.00}]},
    22: {"titulo": "Casamento dos sonhos", "cenario": "Você achou o amor da sua vida e chegou a hora de casar! Como será a festa?",
         "opcoes": [{"texto": "🥂 Vou fazer uma festa de luxo", "saldo": -100000.00},
                    {"texto": "💒 Vou fazer uma festa simples", "saldo": -30000.00},
                    {"texto": "✈️ Acho melhor viajar e gastar menos", "saldo": -10000.00},
                    {"texto": "🚫 Prefiro não fazer festa nem viajar", "saldo": 0.00}]},
    23: {"titulo": "Reserva de emergência", "cenario": "Seu eletrodoméstico quebrou de repente.",
         "opcoes": [{"texto": "💳 Vou comprar outro novo", "saldo": -4000.00},
                    {"texto": "♻️ Vou comprar um usado", "saldo": -1800.00},
                    {"texto": "🛠️ Vou mandar consertar", "saldo": -800.00},
                    {"texto": "🚫 Fico um tempo sem", "saldo": 0.00}]},
    24: {"titulo": "O pet fofinho", "cenario": "Quero adotar um animal de estimação.",
         "opcoes": [{"texto": "🐩 Compro uma raça cara", "saldo": -1000.00},
                    {"texto": "🐕‍🦺 Adoto um caramelo", "saldo": -200.00},
                    {"texto": "🐟 Compro um peixe e um aquário", "saldo": -100.00},
                    {"texto": "🚫 Desisti. Dá muito trabalho.", "saldo": 0.00}]},
    26: {"titulo": "Saúde em dia", "cenario": "Cuidados com a saúde e ingresso na academia.",
         "opcoes": [{"texto": "🏋️ Vou fazer aulas com personal trainer", "saldo": -300.00},
                    {"texto": "🥇 Vou fazer o Plano Premium", "saldo": -200.00},
                    {"texto": "🥈 Vou começar pelo plano básico", "saldo": -60.00},
                    {"texto": "🏃 Prefiro caminhar e correr na rua", "saldo": 0.00}]},
    27: {"titulo": "Filhos!", "cenario": "A família cresceu! Preparativos para o bebê.",
         "opcoes": [{"texto": "🧸 Vou comprar berço novo", "saldo": -2000.00},
                    {"texto": "♻️ Vou comprar berço usado", "saldo": -1500.00}]},
    28: {"titulo": "Férias do trabalho", "cenario": "Período de descanso anual remunerado.",
         "opcoes": [{"texto": "✈️ Vou fazer uma viagem internacional", "saldo": -15000.00},
                    {"texto": "🏖️ Vou fazer uma viagem nacional", "saldo": -5000.00},
                    {"texto": "🚗 Vou viajar para uma cidade vizinha", "saldo": -2500.00},
                    {"texto": "🏠 Vou ficar na minha cidade e organizar algumas coisas", "saldo": 0.00}]},
    30: {"titulo": "O testamento", "cenario": "Aos 45 anos, você recebeu R$ 30.000 de herança de um parente. O que fazer?",
         "opcoes": [
             {"texto": "💰 Mantenho o dinheiro na conta corrente", "saldo": 30000.00},
             {"texto": "🏦 Aplico tudo na Previdência (Contribuição única e extra)", "aporte_unico": 30000.00}
         ]},
    31: {"titulo": "Hobby novo", "cenario": "É hora de dedicar tempo para uma nova atividade de lazer.",
         "opcoes": [{"texto": "🧰 Compro o material novo", "saldo": -2000.00},
                    {"texto": "🤝 Convenço o amigo e dividir o material", "saldo": -1000.00},
                    {"texto": "♻️ Compro o material usado", "saldo": -800.00},
                    {"texto": "🤲 Pego o material emprestado para testar", "saldo": 0.00}]},
    32: {"titulo": "Ajuda à família", "cenario": "Seu filho pediu R$ 20.000 emprestados para abrir um negócio.",
         "opcoes": [{"texto": "💸 Empresto o valor total sem juros", "saldo": -20000.00},
                    {"texto": "📈 Empresto com juros para ganhar em cima", "saldo": 10000.00},
                    {"texto": "🤝 Ajudo com um valor menor", "saldo": -10000.00},
                    {"texto": "🚫 Não ajudo no momento", "saldo": 0.00}]},
    33: {"titulo": "Viagem dos amigos", "cenario": "Você recebeu um convite para um passeio especial em grupo.",
         "opcoes": [{"texto": "👗 Vou no cruzeiro de luxo e renovo minhas roupas", "saldo": -30000.00},
                    {"texto": "🚢 Vou no cruzeiro de luxo", "saldo": -25000.00},
                    {"texto": "♨️ Vou para uma excursão de águas termais", "saldo": -10000.00},
                    {"texto": "🏠 Prefiro ficar em casa", "saldo": 0.00}]},
    36: {"titulo": "Presente para os netos", "cenario": "Compra do presente perfeito de natal.",
         "opcoes": [{"texto": "🎁 Compro o melhor videogame", "saldo": -3000.00},
                    {"texto": "🎮 Compro um modelo mais simples", "saldo": -1000.00},
                    {"texto": "🧩 Dou um presente alternativo", "saldo": -500.00},
                    {"texto": "🍫 Compro uma caixa de bombom", "saldo": -30.00}]},
    37: {"titulo": "Dores da idade", "cenario": "Check-up devido a um desconforto físico.",
         "opcoes": [{"texto": "🏥 Vou a um médico particular", "saldo": -400.00},
                    {"texto": "🩺 Vou ao médico do meu plano", "saldo": -100.00},
                    {"texto": "💊 Compro remédio por minha conta", "saldo": -50.00},
                    {"texto": "⏳ Espero passar e não me cuido", "saldo": 0.00}]},
    38: {"titulo": "Terceira idade", "cenario": "Rotina médica e exames.",
         "opcoes": [{"texto": "👨‍⚕️ Vou aos melhores médicos particulares", "saldo": -5000.00},
                    {"texto": "🏥 Já pago um convênio de saúde bom", "saldo": -500.00},
                    {"texto": "🤕 Utilizo clínicas populares", "saldo": -150.00},
                    {"texto": "🏛️ Uso o sistema de saúde do governo", "saldo": 0.00}]},
    39: {"titulo": "Uso contínuo", "cenario": "Compra dos medicamentos receitados.",
         "opcoes": [{"texto": "💊 Uso medicamentos de marca original", "saldo": -500.00},
                    {"texto": "💊 Substituo por remédios genéricos", "saldo": -100.00}]}
}

EVENTOS_FIXOS = {
    4: {"titulo": "Notas boas", "cenario": "Seus pais te deram dinheiro porque você tem tirado notas boas na escola. Parabéns!", "saldo": 200.00},
    5: {"titulo": "Mesada inesperada", "cenario": "Sua avó resolveu te dar uma mesada até você se formar na faculdade. (Ganha +R$ 200/rodada)", "saldo": 0.00, "flag_mesada": True, "emoji": "👵"},
    10: {"titulo": "Aniversário", "cenario": "Você deu uma festa e gastou mais que devia.", "saldo": -600.00},
    15: {"titulo": "Acidente de percurso", "cenario": "Você se acidentou e precisou de remédios.", "saldo": -200.00},
    20: {"titulo": "Trabalho extra", "cenario": "Freelance no fim de semana.", "saldo": 500.00},
    21: {"titulo": "Promoção no trabalho", "cenario": "PARABÉNS! Você se desempenhou muito bem, recebeu uma promoção e seu salário será dobrado! PARABÉNS!", "saldo": 0.00, "flag_promocao": True},
    25: {"titulo": "Problema mecânico", "cenario": "Que azar! Seu carro ferveu e estragou.", "saldo": -5000.00},
    29: {"titulo": "Hora de Pagar o Imposto de Renda", "cenario": "Hora de acertar as contas com a Receita Federal!", "saldo": 0.00, "regra_ir": True},
    34: {"titulo": "Reforma da casa", "cenario": "Sua casa precisa de adaptação.", "saldo": -25000.00},
    35: {"titulo": "Dores da idade", "cenario": "Despesas com fisioterapia e itens ortopédicos.", "saldo": -1500.00}
}

# ==========================================
# 🧮 FUNÇÕES ÚTEIS E FORMATAÇÕES
# ==========================================
def fmt_saldo(v):
    return f"R$ {int(abs(v)):,}".replace(",", ".") + ",00"

def fmt_grana_exata(v):
    s = f"{int(v):,}".replace(",", ".")
    return f"R$ {s},00"

def agrupar_emojis(emoji_str):
    if not emoji_str: return ""
    conhecidos = ["🏦", "📚", "📈", "💼", "🎓", "👵", "🌾", "🧬", "💻", "🎭"]
    res = []
    for e in conhecidos:
        qtd = emoji_str.count(e)
        if qtd == 1: res.append(e)
        elif qtd > 1: res.append(f"{qtd}x{e}")
    return " ".join(res)

def agrupar_emojis_html(emoji_str, font_size="18px"):
    if not emoji_str: return ""
    conhecidos = ["🏦", "📚", "📈", "💼", "🎓", "👵", "🌾", "🧬", "💻", "🎭"]
    res = []
    for e in conhecidos:
        qtd = emoji_str.count(e)
        if qtd == 1:
            res.append(e)
        elif qtd > 1:
            res.append(f"<span style='font-size: {font_size}; color: #757575;'>{qtd}x</span>{e}")
    return " ".join(res)

# ==========================================
# 🗺️ LÓGICA DE COORDENADAS DO TABULEIRO
# ==========================================
def gerar_coordenadas():
    coords = [(0, 0)]
    r, c = 0, 0
    padrao = ['R'] * 9 + ['D'] * 2 + ['L'] * 9 + ['D'] * 2
    seq = padrao * 10
    for i in range(TOTAL_CASAS - 1):
        p = seq[i]
        if p == 'R':
            c += 1
        elif p == 'L':
            c -= 1
        elif p == 'D':
            r += 1
        coords.append((r, c))
    return coords

COORDENADAS = gerar_coordenadas()
MAX_R = max(r for r, c in COORDENADAS)
MAX_C = max(c for r, c in COORDENADAS)

def cor_da_casa(num):
    if num == 1: return "#FFD700"
    if num == TOTAL_CASAS: return "#FF4500"
    if num in [3, 13, 20, 24, 30]: return "#1A237E"
    if num % 5 == 0: return "#00BCD4"
    return CORES_CASAS[(num - 1) % len(CORES_CASAS)]
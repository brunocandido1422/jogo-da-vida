import flet as ft
import random
import time
import threading
import dados_jogo

# ==========================================
# ⚙️ CONFIGURAÇÕES E DADOS DO JOGO
# ==========================================
TOTAL_CASAS = 40
SALDO_INICIAL = 1621
PREMIOS_CHEGADA = [60000, 30000, 20000, 10000]

CORES_CASAS = [
    "#E53935", "#8E24AA", "#1E88E5", "#00897B", "#F4511E",
    "#6D4C41", "#039BE5", "#43A047", "#FB8C00", "#3949AB"
]


def fmt_saldo(v):
    return f"R$ {int(abs(v)):,}".replace(",", ".") + ",00"


# ==========================================
# ⚖️ DILEMAS FIXOS E EVENTOS
# ==========================================
DILEMAS_FIXOS = {
    1: {"titulo": "A mesada", "cenario": "Você recebeu sua mesada do mês. O que você faz?",
        "opcoes": [{"texto": "👗 Gasto tudo com roupas novas", "saldo": -150.00},
                   {"texto": "🍿 Uso metade com lazer e guardo o restante", "saldo": -75.00},
                   {"texto": "📚 Compro um livro novo", "saldo": -80.00, "livros": 1},
                   {"texto": "🐷 Guardo tudo para o futuro", "saldo": 150.00}]},
    2: {"titulo": "Material escolar",
        "cenario": "Início do ano chegou e com ele o momento de comprar cadernos. O que fazer?",
        "opcoes": [{"texto": "📓 Compro cadernos que são lançamentos", "saldo": -80.00},
                   {"texto": "📓 Compro cadernos em promoção", "saldo": -30.00}]},
    3: {"titulo": "Hora do lanche", "cenario": "Bateu uma fome na escola! Que tal um lanchinho entre as aulas?",
        "opcoes": [{"texto": "🍔 Compro um lanche na escola", "saldo": -20.00},
                   {"texto": "🤝 Compro um lanche dividido com um amigo", "saldo": -10.00},
                   {"texto": "🥪 Faço lanche em casa e levo para a escola", "saldo": -8.00},
                   {"texto": "🚫 Não lancho e fico com fome", "saldo": 0.00}]},
    6: {"titulo": "Passeio escolar",
        "cenario": "A escola organizou uma viagem para uma cidade histórica. O que você faz?",
        "opcoes": [{"texto": "🚌 Pago e viajo", "saldo": -150.00},
                   {"texto": "🏠 Fico em casa", "saldo": 0.00}]},
    7: {"titulo": "O tênis da moda", "cenario": "Teve o lançamento de um tênis desejado.",
        "opcoes": [{"texto": "👟 Compro agora", "saldo": -500.00},
                   {"texto": "🏷️ Espero entrar em promoção", "saldo": -350.00},
                   {"texto": "🥾 Compro um tênis mais barato", "saldo": -250.00},
                   {"texto": "👟 Uso o que tenho e economizo", "saldo": 0.00}]},
    8: {"titulo": "Roupa para festa", "cenario": "Uma festa do colegial está chegando.",
        "opcoes": [{"texto": "👗 Compro roupas novas", "saldo": -200.00},
                   {"texto": "👕 Uso as roupas que já tenho", "saldo": 0.00}]},
    9: {"titulo": "Cinema no final de semana", "cenario": "A turma toda vai ao cinema ver o filme indicado ao Oscar.",
        "opcoes": [{"texto": "🍿 Compro o ingresso, pipoca e refri", "saldo": -60.00},
                   {"texto": "🎟️ Compro somente o Ingresso", "saldo": -40.00},
                   {"texto": "🍔 Compro um lanche e não vou ao cinema", "saldo": -30.00},
                   {"texto": "🏠 Fico em casa", "saldo": 0.00}]},
    11: {"titulo": "Morar na república ou sozinho?",
         "cenario": "É hora de decidir onde morar durante o período da universidade.",
         "opcoes": [{"texto": "🏠 Vou morar em uma Kitnet sozinho", "saldo": -800.00},
                    {"texto": "👥 Vou dividir república", "saldo": -400.00},
                    {"texto": "😒 Vou alugar um quarto na casa de um tio desagradável", "saldo": -100.00},
                    {"texto": "🛏️ Vou morar em um alojamento", "saldo": 0.00}]},
    12: {"titulo": "Xerox ou original", "cenario": "O professor pediu um livro base importante para seu curso.",
         "opcoes": [{"texto": "📖 Compro o original", "saldo": -120.00, "livros": 1},
                    {"texto": "📄 Tiro um xerox", "saldo": -15.00},
                    {"texto": "🧠 Não preciso ler, já tenho conhecimento", "saldo": 0.00},
                    {"texto": "📚 Leio na biblioteca", "saldo": 0.00}]},
    13: {"titulo": "Congresso acadêmico", "cenario": "Terá um evento importante em outra cidade.",
         "opcoes": [{"texto": "🌟 Pago a inscrição com área VIP e viajo", "saldo": -750.00},
                    {"texto": "✈️ Pago a inscrição e viajo", "saldo": -500.00},
                    {"texto": "💻 Faço a inscrição para o evento online e assisto algumas palestras", "saldo": -200.00},
                    {"texto": "🚫 Não participo", "saldo": 0.00}]},
    14: {"titulo": "Festa ou prova",
         "cenario": "Você sabe que se divertir é importante e surgiu uma festa badalada na véspera de prova.",
         "opcoes": [{"texto": "👗 Vou à festa e compro roupa nova", "saldo": -250.00},
                    {"texto": "🎉 Vou à festa", "saldo": -100.00},
                    {"texto": "🎶 Vou à uma festa menos badalada", "saldo": -50.00},
                    {"texto": "📚 Fico em casa estudando", "saldo": 0.00}]},
    16: {"titulo": "O notebook quebrou",
         "cenario": "Seu computador pifou na semana de entrega de trabalhos importantes.",
         "opcoes": [{"texto": "💻 Compro um novo porque é mais rápido", "saldo": -2000.00},
                    {"texto": "🛠️ Mando arrumar", "saldo": -500.00},
                    {"texto": "🖥️ Alugo um tempo na Lan house", "saldo": -100.00},
                    {"texto": "🤝 Pego emprestado com um amigo", "saldo": 0.00}]},
    17: {"titulo": "Atrasado para a aula", "cenario": "Está chovendo muito no horário da aula.",
         "opcoes": [{"texto": "🚕 Vou de carro por aplicativo", "saldo": -30.00},
                    {"texto": "🤝 Divido o aplicativo de carro com um amigo", "saldo": -15.00},
                    {"texto": "🚌 Vou de ônibus", "saldo": -5.00},
                    {"texto": "☔ Encaro a chuva e vou a pé", "saldo": 0.00}]},
    18: {"titulo": "Oportunidade de estágio", "cenario": "Aprendizado ou dinheiro rápido?",
         "opcoes": [{"texto": "💼 Prefiro fazer freelancers", "saldo": 750.00},
                    {"texto": "🎓 Aceito o estágio acadêmico", "saldo": 500.00}]},
    19: {"titulo": "Lançou a Nova Temporada", "cenario": "Lançamento da nova temporada da sua série favorita.",
         "opcoes": [{"texto": "📺 Assino e pago sozinho", "saldo": -40.00},
                    {"texto": "🤝 Divido com os amigos", "saldo": -10.00}]},
    22: {"titulo": "Casamento dos sonhos",
         "cenario": "Você achou o amor da sua vida e chegou a hora de casar! Como será a festa?",
         "opcoes": [{"texto": "🥂 Vou fazer uma festa de luxo", "saldo": -100000.00},
                    {"texto": "💒 Vou fazer uma festa simples", "saldo": -30000.00},
                    {"texto": "✈️ Acho melhor viajar e gastar menos", "saldo": -10000.00},
                    {"texto": "🚫 Prefiro não fazer festa nem viajar", "saldo": 0.00}]},
    23: {"titulo": "Reserva de emergência", "cenario": "Seu eletrodoméstico quebrou de repente.",
         "opcoes": [{"texto": "💳 Vou comprar outro novo", "saldo": -4000.00},
                    {"texto": "♻️ Vou comprar um usado", "saldo": -1800.00},
                    {"texto": "🛠️ Vou mandar consertar", "saldo": -800.00},
                    {"texto": "🚫 Fico um tempo sem", "saldo": 0.00}]},
    24: {"titulo": "O pet fofinho", "cenario": "Quero adotar um animal de estimação.",
         "opcoes": [{"texto": "🐩 Compro uma raça cara", "saldo": -1000.00},
                    {"texto": "🐕‍🦺 Adoto um caramelo", "saldo": -200.00},
                    {"texto": "🐟 Compro um peixe e um aquário", "saldo": -100.00},
                    {"texto": "🚫 Desisti. Dá muito trabalho.", "saldo": 0.00}]},
    26: {"titulo": "Saúde em dia", "cenario": "Cuidados com a saúde e ingresso na academia.",
         "opcoes": [{"texto": "🏋️ Vou fazer aulas com personal trainer", "saldo": -300.00},
                    {"texto": "🥇 Vou fazer o Plano Premium", "saldo": -200.00},
                    {"texto": "🥈 Vou começar pelo plano básico", "saldo": -60.00},
                    {"texto": "🏃 Prefiro caminhar e correr na rua", "saldo": 0.00}]},
    27: {"titulo": "Filhos!", "cenario": "A família cresceu! Preparativos para o bebê.",
         "opcoes": [{"texto": "🧸 Vou comprar berço novo", "saldo": -2000.00},
                    {"texto": "♻️ Vou comprar berço usado", "saldo": -1500.00}]},
    28: {"titulo": "Férias do trabalho", "cenario": "Período de descanso anual remunerado.",
         "opcoes": [{"texto": "✈️ Vou fazer uma viagem internacional", "saldo": -15000.00},
                    {"texto": "🏖️ Vou fazer uma viagem nacional", "saldo": -5000.00},
                    {"texto": "🚗 Vou viajar para uma cidade vizinha", "saldo": -2500.00},
                    {"texto": "🏠 Vou ficar na minha cidade e organizar algumas coisas", "saldo": 0.00}]},
    30: {"titulo": "O testamento",
         "cenario": "Aos 45 anos, você recebeu R$ 30.000 de herança de um parente. O que fazer?",
         "opcoes": [
             {"texto": "💰 Mantenho o dinheiro na conta corrente", "saldo": 30000.00},
             {"texto": "🏦 Aplico tudo na Previdência", "aporte_unico": 30000.00}
         ]},
    31: {"titulo": "Hobby novo", "cenario": "É hora de dedicar tempo para uma nova atividade de lazer.",
         "opcoes": [{"texto": "🧰 Compro o material novo", "saldo": -2000.00},
                    {"texto": "🤝 Convenço o amigo e dividir o material", "saldo": -1000.00},
                    {"texto": "♻️ Compro o material usado", "saldo": -800.00},
                    {"texto": "🤲 Pego o material emprestado para testar", "saldo": 0.00}]},
    32: {"titulo": "Ajuda à família", "cenario": "Seu filho pediu R$ 20.000 emprestados para abrir um negócio.",
         "opcoes": [{"texto": "💸 Empresto o valor total sem juros", "saldo": -20000.00},
                    {"texto": "📈 Empresto com juros para ganhar em cima", "saldo": 10000.00},
                    {"texto": "🤝 Ajudo com um valor menor", "saldo": -10000.00},
                    {"texto": "🚫 Não ajudo no momento", "saldo": 0.00}]},
    33: {"titulo": "Viagem dos amigos", "cenario": "Você recebeu um convite para um passeio especial em grupo.",
         "opcoes": [{"texto": "👗 Vou no cruzeiro de luxo e renovo minhas roupas", "saldo": -30000.00},
                    {"texto": "🚢 Vou no cruzeiro de luxo", "saldo": -25000.00},
                    {"texto": "♨️ Vou para uma excursão de águas termais", "saldo": -10000.00},
                    {"texto": "🏠 Prefiro ficar em casa", "saldo": 0.00}]},
    36: {"titulo": "Presente para os netos", "cenario": "Compra do presente perfeito de natal.",
         "opcoes": [{"texto": "🎁 Compro o melhor videogame", "saldo": -3000.00},
                    {"texto": "🎮 Compro um modelo mais simples", "saldo": -1000.00},
                    {"texto": "🧩 Dou um presente alternativo", "saldo": -500.00},
                    {"texto": "🍫 Compro uma caixa de bombom", "saldo": -30.00}]},
    37: {"titulo": "Dores da idade", "cenario": "Check-up devido a um desconforto físico.",
         "opcoes": [{"texto": "🏥 Vou a um médico particular", "saldo": -400.00},
                    {"texto": "🩺 Vou ao médico do meu plano", "saldo": -100.00},
                    {"texto": "💊 Compro remédio por minha conta", "saldo": -50.00},
                    {"texto": "⏳ Espero passar e não me cuido", "saldo": 0.00}]},
    38: {"titulo": "Terceira idade", "cenario": "Rotina médica e exames.",
         "opcoes": [{"texto": "👨‍⚕️ Vou aos melhores médicos particulares", "saldo": -5000.00},
                    {"texto": "🏥 Já pago um convênio de saúde bom", "saldo": -500.00},
                    {"texto": "🤕 Utilizo clínicas populares", "saldo": -150.00},
                    {"texto": "🏛️ Uso o sistema de saúde do governo", "saldo": 0.00}]},
    39: {"titulo": "Uso contínuo", "cenario": "Compra dos medicamentos receitados.",
         "opcoes": [{"texto": "💊 Uso medicamentos de marca original", "saldo": -500.00},
                    {"texto": "💊 Substituo por remédios genéricos", "saldo": -100.00}]}
}

EVENTOS_FIXOS = {
    4: {"titulo": "Notas boas",
        "cenario": "Seus pais te deram dinheiro porque você tem tirado notas boas na escola. Parabéns!",
        "saldo": 200.00},
    5: {"titulo": "Mesada inesperada", "cenario": "Sua avó resolveu te dar uma mesada até você se formar na faculdade.",
        "saldo": 0.00, "flag_mesada": True, "emoji": "👵"},
    10: {"titulo": "Aniversário", "cenario": "Você deu uma festa e gastou mais que devia.", "saldo": -600.00},
    15: {"titulo": "Acidente de percurso", "cenario": "Você se acidentou e precisou de remédios.", "saldo": -200.00},
    20: {"titulo": "Trabalho extra", "cenario": "Freelance no fim de semana.", "saldo": 500.00},
    21: {"titulo": "Promoção no trabalho",
         "cenario": "PARABÉNS! Você se desempenhou muito bem, recebeu uma promoção e seu salário será dobrado!",
         "saldo": 0.00, "flag_promocao": True},
    25: {"titulo": "Problema mecânico", "cenario": "Que azar! Seu carro ferveu e estragou.", "saldo": -5000.00},
    29: {"titulo": "Hora de Pagar o Imposto de Renda",
         "cenario": "Hora de acertar as contas com a Receita Federal!",
         "saldo": 0.00,
         "regra_ir": True},
    34: {"titulo": "Reforma da casa", "cenario": "Sua casa precisa de adaptação.", "saldo": -25000.00},
    35: {"titulo": "Dores da idade", "cenario": "Despesas com fisioterapia e itens ortopédicos.", "saldo": -1500.00}
}


def main(page: ft.Page):
    page.title = "O Jogo da Vida"
    page.padding = 0
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = "#F5F5F5"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    equipes = []
    ordem_final = []
    modo_turbo = False

    lista_placar = ft.ListView(expand=True, spacing=10)
    lbl_vez_nome = ft.Text("Nome da Equipe", size=17, weight="900", color="white", text_align="center")
    barra_cor_vez = ft.Container(height=5, bgcolor="#E53935", border_radius=2)

    def cor_da_casa(num):
        if num == 1: return "#FFD700"
        if num == TOTAL_CASAS: return "#FF4500"
        if num in [3, 13, 20, 24, 30]: return "#1A237E"
        if num % 5 == 0: return "#00BCD4"
        return CORES_CASAS[(num - 1) % len(CORES_CASAS)]

    def gerar_coordenadas():
        coords = [(0, 0)]
        r, c = 0, 0
        padrao = ['R'] * 9 + ['D'] * 2 + ['L'] * 9 + ['D'] * 2
        seq = padrao * 10
        for i in range(TOTAL_CASAS - 1):
            p = seq[i]
            if p == 'R':
                c += 1
            elif p == 'L':
                c -= 1
            elif p == 'D':
                r += 1
            coords.append((r, c))
        return coords

    COORDENADAS = gerar_coordenadas()

    # ==========================================
    # MOTOR DO JOGO E CONTROLE DE TURNOS
    # ==========================================
    turno_atual = [0]
    camada_pinos = ft.Stack(expand=True)
    fila_eventos = []
    jogo_finalizado = [False]
    formados = []

    def atualizar_tela_jogo():
        lista_placar.controls.clear()
        eq_vez = equipes[turno_atual[0]]

        lbl_vez_nome.value = eq_vez["nome"]
        barra_cor_vez.bgcolor = dados_jogo.CORES_EQUIPES[turno_atual[0] % len(dados_jogo.CORES_EQUIPES)]

        for i, eq in enumerate(equipes):
            cor = dados_jogo.CORES_EQUIPES[i % len(dados_jogo.CORES_EQUIPES)]
            ativo = (i == turno_atual[0])

            renda_liquida = eq["salario_base"] + eq["renda_extra"] - eq["investimento_turno"]
            sinal_r = "+" if renda_liquida > 0 else "-" if renda_liquida < 0 else ""
            cor_r = "#1976D2" if renda_liquida > 0 else "#D32F2F" if renda_liquida < 0 else "#999999"

            saldo_fmt = f"R$ {int(abs(eq['saldo'])):,}".replace(",", ".") + ",00"
            renda_fmt = f"{int(abs(renda_liquida)):,}".replace(",", ".") + ",00"

            lista_placar.controls.append(
                ft.Container(
                    bgcolor="#F5F5F5" if ativo else "white",
                    border_radius=10, padding=10,
                    border=ft.Border(left=ft.BorderSide(width=5, color=cor),
                                     top=ft.BorderSide(width=1, color="#E0E0E0" if ativo else "#F0F0F0"),
                                     right=ft.BorderSide(width=1, color="#E0E0E0" if ativo else "#F0F0F0"),
                                     bottom=ft.BorderSide(width=1, color="#E0E0E0" if ativo else "#F0F0F0")),
                    content=ft.Column([
                        ft.Row([ft.Text(f"{eq['nome']} {eq['emojis']}", weight="900" if ativo else "bold", color=cor),
                                ft.Container(expand=True), ft.Text(f"Casa {eq['posicao']}", size=11, color="#999")]),
                        ft.Row([ft.Text(f"💰 {saldo_fmt}", weight="800",
                                        color="#2E7D32" if eq['saldo'] >= 0 else "#C62828"), ft.Container(expand=True),
                                ft.Text(f"(Renda: {sinal_r}{renda_fmt}/rod)", size=11, color=cor_r, weight="600")])
                    ], spacing=2)
                )
            )

        camada_pinos.controls.clear()
        grupos = {}
        for i_eq, eq in enumerate(equipes):
            pos = eq["posicao"]
            if pos >= 1:
                if pos not in grupos: grupos[pos] = []
                grupos[pos].append(i_eq)

        for pos, indices in grupos.items():
            if pos < 1 or pos > TOTAL_CASAS: continue
            r, c = COORDENADAS[pos - 1]
            centro_casa_x = c * 110 + 92
            topo_casa_y = r * 80 + 40
            n = len(indices)
            for j, eq_idx in enumerate(indices):
                eq = equipes[eq_idx]
                offset_x = (j - (n - 1) / 2) * 22
                cor = dados_jogo.CORES_EQUIPES[eq_idx % len(dados_jogo.CORES_EQUIPES)]

                pino = ft.Container(
                    content=ft.Text(eq['nome'][0].upper(), color="white", weight="900", size=18),
                    width=40, height=40, bgcolor=cor, border_radius=20,
                    border=ft.Border(top=ft.BorderSide(width=2, color="white"),
                                     bottom=ft.BorderSide(width=2, color="white"),
                                     left=ft.BorderSide(width=2, color="white"),
                                     right=ft.BorderSide(width=2, color="white")),
                    alignment=ft.Alignment(0, 0),
                    left=centro_casa_x - 20 + offset_x,
                    top=topo_casa_y - 25,
                    shadow=ft.BoxShadow(blur_radius=5, color="black54", offset=ft.Offset(2, 3)),
                    tooltip=f"{eq['nome']} (Casa {pos})"
                )
                camada_pinos.controls.append(pino)

        page.update()

    # ==========================================
    # LÓGICA DOS EVENTOS E DILEMAS (CARTAS)
    # ==========================================

    def calcular_slider_val(val_puro):
        return 0 if val_puro == 0 else 50 + val_puro * 50

    def gerar_card_marco(marco, eq):
        invest_atual = eq.get("investimento_turno", 0)

        if marco == 3:
            return {
                "titulo": "DECISÃO PARA O FUTURO",
                "cenario": "Você está com 16 anos e o tempo está passando rápido. Você já pode fazer sua Previdência Complementar e também focar no seu conhecimento. Quais serão suas escolhas?",
                "slider": True, "valor_atual": invest_atual, "idade_marco": 16,
                "opcoes": [
                    {"template": "🏦 Contribuir na Previdência (R$ {val},00)", "emoji": "🏦"},
                    {"template": "📚 Comprar Livros (-R$ 500) E 🏦 Contribuir (R$ {val})", "livros": 1, "saldo": -500,
                     "emoji": "🏦📚"},
                    {"texto": "📚 Apenas Comprar Livros (-R$ 500,00)", "livros": 1, "saldo": -500, "invest_set": 0,
                     "emoji": "📚"},
                    {"texto": "🚫 Não estudar e Não Contribuir: R$ 0,00", "invest_set": 0}
                ]
            }
        elif marco == 10:
            return {
                "titulo": "VOCÊ ENTROU NA FACULDADE!",
                "cenario": "Aos 18 anos, chegou a hora de escolher o seu caminho acadêmico para o futuro.",
                "opcoes": [
                    {"texto": "🌾 Agrárias", "emoji": "🌾", "saldo": 0},
                    {"texto": "🧬 Biológicas", "emoji": "🧬", "saldo": 0},
                    {"texto": "💻 Exatas", "emoji": "💻", "saldo": 0},
                    {"texto": "🎭 Humanas", "emoji": "🎭", "saldo": 0}
                ]
            }
        elif marco == 13:
            return {
                "titulo": "NOVA DECISÃO DE FUTURO",
                "cenario": "Você está com 20 anos. A faculdade exige mais. Que tal planejar e se preparar para o futuro? Você pode reajustar a Previdência Complementar.",
                "slider": True, "valor_atual": invest_atual, "idade_marco": 20,
                "opcoes": [
                    {"template": "🏦 Contribuir na Previdência (R$ {val},00)", "emoji": "🏦"},
                    {"template": "📚 Comprar Livros (-R$ 500) E 🏦 Contribuir (R$ {val})", "livros": 1, "saldo": -500,
                     "emoji": "🏦📚"},
                    {"texto": "📚 Apenas Comprar Livros (-R$ 500,00)", "livros": 1, "saldo": -500, "invest_set": 0,
                     "emoji": "📚"},
                    {"texto": "🚫 Não estudar e Não Contribuir: R$ 0,00", "invest_set": 0}
                ]
            }
        elif marco == 20:
            salario = 3500 if eq["qtd_livros"] == 0 else 3750 if eq["qtd_livros"] == 1 else 4000
            return {
                "sem_escolha": True,
                "titulo": "MERCADO DE TRABALHO",
                "cenario": f"Aos 24 anos, você se formou e conseguiu um emprego!\n\nSua renda base agora é R$ {salario},00/rodada.\n(Caso tenha mesada da avó, ela será cancelada!)",
                "novo_salario_base": salario,
                "corta_mesada": True, "saldo": 0, "emoji": "💼"
            }
        elif marco == 24:
            return {
                "titulo": "OS 30 ANOS CHEGARAM",
                "cenario": "Aos 30 anos, você já está consolidado. Vai turbinar a sua carreira ou focar nas contribuições?",
                "slider": True, "valor_atual": invest_atual, "idade_marco": 30,
                "opcoes": [
                    {"template": "🏦 Contribuir na Previdência (R$ {val},00)", "emoji": "🏦"},
                    {"template": "🎓 Fazer Pós (-R$ 3.000) E 🏦 Contribuir (R$ {val})", "add_salario": 1500,
                     "saldo": -3000, "emoji": "🏦🎓"},
                    {"texto": "🎓 Apenas Pós (-R$ 3.000,00)", "add_salario": 1500, "saldo": -3000, "invest_set": 0,
                     "emoji": "🎓"},
                    {"texto": "🚫 Não estudar e Não Contribuir: R$ 0,00", "invest_set": 0}
                ]
            }
        elif marco == 30:
            return {
                "titulo": "A CHEGADA DOS 45 ANOS",
                "cenario": "Você chegou aos 45 anos. É a hora de garantir a aposentadoria ou se capacitar para virar Senior!",
                "slider": True, "valor_atual": invest_atual, "idade_marco": 45,
                "opcoes": [
                    {"template": "🏦 Contribuir na Previdência (R$ {val},00)", "emoji": "🏦"},
                    {"template": "📈 Capacitar p/ Sênior (-R$ 2.500) E 🏦 Contribuir (R$ {val})", "add_salario": 1000,
                     "saldo": -2500, "emoji": "🏦📈"},
                    {"texto": "📈 Só Capacitar para Sênior (-R$ 2.500,00)", "add_salario": 1000, "saldo": -2500,
                     "invest_set": 0, "emoji": "📈"},
                    {"texto": "🚫 Não capacitar e Não Contribuir: R$ 0,00", "invest_set": 0}
                ]
            }

    def processar_proximo_evento():
        if not fila_eventos:
            avancar_turno()
            return

        ev = fila_eventos.pop(0)
        eq = equipes[turno_atual[0]]

        if ev["tipo"] == "chegada":
            if not eq["formado"]:
                eq["formado"] = True
                formados.append(eq["nome"])

            pos_chegada = formados.index(eq["nome"]) + 1
            idx = min(pos_chegada - 1, len(PREMIOS_CHEGADA) - 1)
            mostrar_modal_evento(eq["nome"], {
                "sem_escolha": True,
                "titulo": "CHEGADA / APOSENTADORIA",
                "cenario": f"Você completou 65 anos, hora de se aposentar!\n\nParabéns! Você concluiu a jornada em {pos_chegada}º lugar!",
                "saldo": PREMIOS_CHEGADA[idx]
            })

        elif ev["tipo"] == "card":
            mostrar_modal_evento(eq["nome"], ev["dados"])

        elif ev["tipo"] == "marco":
            dados_marco = gerar_card_marco(ev["num"], eq)
            mostrar_modal_evento(eq["nome"], dados_marco)

    def aplicar_consequencia_evento(dados_op):
        eq = equipes[turno_atual[0]]
        btn_avancar_evento.disabled = False

        # CORREÇÃO CRÍTICA 1: Repassa a idade do marco para salvar nos aportes por idade
        if "idade_marco" in enquete_atual_ref and "idade_marco" not in dados_op:
            dados_op["idade_marco"] = enquete_atual_ref["idade_marco"]

        if enquete_atual_ref.get("slider") and "template" in dados_op:
            val_invest = calcular_slider_val(int(slider_evento.value))
            dados_op["invest_set"] = val_invest
            if val_invest == 0 and "emoji" in dados_op:
                dados_op["emoji"] = dados_op["emoji"].replace("🏦", "")

        eq["saldo"] += dados_op.get("saldo", 0)
        eq["emojis"] += dados_op.get("emoji", "")
        eq["qtd_livros"] += dados_op.get("livros", 0)

        if dados_op.get("corta_mesada") and eq.get("tem_mesada_vo"):
            eq["renda_extra"] -= 200
            eq["tem_mesada_vo"] = False
            eq["emojis"] = eq["emojis"].replace("👵", "")

        if dados_op.get("flag_mesada"):
            eq["renda_extra"] += 200
            eq["tem_mesada_vo"] = True

        if dados_op.get("flag_promocao"):
            eq["salario_base"] = eq.get("salario_base", 0) * 2

        if "novo_salario_base" in dados_op:
            eq["salario_base"] = dados_op["novo_salario_base"]

        if "add_salario" in dados_op:
            eq["salario_base"] += dados_op["add_salario"]

        if "invest_set" in dados_op:
            eq["investimento_turno"] = dados_op["invest_set"]

        if "idade_marco" in dados_op:
            idade = dados_op["idade_marco"]
            eq[f"aporte_{idade}"] = eq["investimento_turno"]

        if "aporte_unico" in dados_op:
            if "aportes_unicos" not in eq:
                eq["aportes_unicos"] = []
            eq["aportes_unicos"].append({"casa": eq["posicao"], "valor": dados_op["aporte_unico"]})

        # CORREÇÃO CRÍTICA 2: Salva no Histórico de Escolhas da Equipe
        if "historico_escolhas" not in eq:
            eq["historico_escolhas"] = []

        txt_hist = dados_op.get("texto_hist", dados_op.get("texto", dados_op.get("template",
                                                                                 enquete_atual_ref.get("titulo",
                                                                                                       "Evento"))))
        if "{val}" in txt_hist and "invest_set" in dados_op:
            txt_hist = txt_hist.replace("{val}", str(dados_op["invest_set"]))

        eq["historico_escolhas"].append({
            "casa": eq["posicao"],
            "texto": txt_hist,
            "saldo": dados_op.get("saldo", 0),
            "invest": dados_op.get("invest_set", None)
        })

        lbl_resultado_evento.controls.clear()
        s = dados_op.get("saldo", 0)

        if s != 0:
            cor = "#2E7D32" if s >= 0 else "#C62828"
            lbl_resultado_evento.controls.append(
                ft.Text(f"💰 {'+' if s > 0 else ''}{fmt_saldo(s)}", color=cor, weight="900", size=20))

        if "invest_set" in dados_op:
            lbl_resultado_evento.controls.append(
                ft.Text(f"🏦 Contribuição: R$ {dados_op['invest_set']},00/rodada", color="#1976D2", weight="bold",
                        size=16))

        if "aporte_unico" in dados_op:
            lbl_resultado_evento.controls.append(
                ft.Text(f"🏦 Aporte Único: + {fmt_saldo(dados_op['aporte_unico'])}", color="#1976D2", weight="bold",
                        size=16))

        if dados_op.get("livros"):
            lbl_resultado_evento.controls.append(
                ft.Text("📚 Novo Conhecimento Adquirido!", color="#F57C00", weight="bold", size=16))

        if dados_op.get("flag_mesada"):
            lbl_resultado_evento.controls.append(
                ft.Text("👵 Vovó te ama! Renda Extra: +R$ 200,00/rodada", color="#1976D2", weight="bold", size=16))

        if dados_op.get("corta_mesada"):
            lbl_resultado_evento.controls.append(
                ft.Text("❌ Fim da Mesada da Vovó!", color="#C62828", weight="bold", size=16))

        if "novo_salario_base" in dados_op:
            lbl_resultado_evento.controls.append(
                ft.Text(f"💼 Nova Renda Base: R$ {dados_op['novo_salario_base']},00", color="#388E3C", weight="bold",
                        size=16))

        if "add_salario" in dados_op:
            lbl_resultado_evento.controls.append(
                ft.Text(f"💼 Promoção! +R$ {dados_op['add_salario']},00 na Renda", color="#388E3C", weight="bold",
                        size=16))

        if dados_op.get("emoji"):
            lbl_resultado_evento.controls.append(
                ft.Text(f"⭐ Você ganhou: {dados_op['emoji']}", color="#333", size=18, weight="900"))

        if not lbl_resultado_evento.controls:
            lbl_resultado_evento.controls.append(
                ft.Text("Nenhum impacto financeiro imediato.", color="#555", size=16, italic=True))

        col_slider_inteira.visible = False
        botoes_evento_col.visible = False

        container_resultado.visible = True
        lbl_resultado_evento.visible = True
        btn_avancar_evento.visible = True
        page.update()

    def fechar_evento_passar_fila(e):
        btn_avancar_evento.disabled = True
        card_evento.scale = 0.8
        card_evento.opacity = 0
        page.update()
        time.sleep(0.3)
        wrapper_evento.visible = False
        page.update()
        processar_proximo_evento()

    # ==========================================
    # CÁLCULO E TELAS DO FIM DO JOGO
    # ==========================================
    ranking_calculado = []
    idx_ranking = [0]

    def calcular_ranking_final():
        for e in equipes:
            a16 = e.get("aporte_16", 0) if "aporte_16" in e else e.get("a16", 0)
            a20 = e.get("aporte_20", a16) if "aporte_20" in e else e.get("a20", a16)
            a30 = e.get("aporte_30", a20) if "aporte_30" in e else e.get("a30", a20)
            a45 = e.get("aporte_45", a30) if "aporte_45" in e else e.get("a45", a30)

            saldo_prev = 0
            hist = [0]
            bolso = 0

            aportes_extras = {}
            for au in e.get("aportes_unicos", []):
                mes_exato = 348 if au["casa"] == 30 else int((au["casa"] / 40.0) * 588)
                if mes_exato >= 588: mes_exato = 587
                aportes_extras[mes_exato] = aportes_extras.get(mes_exato, 0) + au["valor"]

            for mes in range(588):
                if mes < 48:
                    pmt = a16
                elif mes < 168:
                    pmt = a20
                elif mes < 348:
                    pmt = a30
                else:
                    pmt = a45

                saldo_prev = saldo_prev * 1.01 + pmt
                bolso += pmt

                if mes in aportes_extras:
                    valor_extra = aportes_extras[mes]
                    saldo_prev += valor_extra
                    bolso += valor_extra

                hist.append(saldo_prev)

            e["prev_hist"] = hist
            e["prev_bolso"] = bolso
            e["prev_juros"] = saldo_prev - bolso

            txt_hist = f"  • Dos 16 aos 20 anos: R$ {a16},00/mês\n  • Dos 20 aos 30 anos: R$ {a20},00/mês\n  • Dos 30 aos 45 anos: R$ {a30},00/mês\n  • Dos 45 aos 65 anos: R$ {a45},00/mês"
            if e.get("aportes_unicos"):
                txt_hist += "\n  • Aportes Extras: " + ", ".join(
                    [f"{fmt_saldo(au['valor'])} (Casa {au['casa']})" for au in e["aportes_unicos"]])
            e["historico_aportes_txt"] = txt_hist

            if e["saldo"] < 0:
                e["patrimonio_total"] = e["saldo"]
            else:
                e["patrimonio_total"] = e["saldo"] + saldo_prev

        positivos = [e for e in equipes if e["saldo"] >= 0]
        negativados = [e for e in equipes if e["saldo"] < 0]

        positivos.sort(key=lambda x: -x["patrimonio_total"])
        negativados.sort(key=lambda x: -x["patrimonio_total"])

        nonlocal ranking_calculado
        ranking_calculado = positivos + negativados

    def exibir_equipe_ranking():
        eq = ranking_calculado[idx_ranking[0]]
        pos = idx_ranking[0] + 1

        if pos == 1:
            lbl_rk_pos.value = "🏆 1º LUGAR - GRANDE CAMPEÃO!"
            lbl_rk_pos.color = "#FBC02D"
            btn_rk_next.text = "Classificação Geral ➡️"
            btn_rk_next.bgcolor = "#43A047"
        else:
            lbl_rk_pos.value = f"{pos}º LUGAR"
            lbl_rk_pos.color = "#999"
            btn_rk_next.text = "Avançar ➡️"
            btn_rk_next.bgcolor = "#FF9800"

        btn_rk_prev.disabled = (idx_ranking[0] == len(ranking_calculado) - 1)
        lbl_rk_nome.value = f"{eq['nome']} {eq['emojis']}"

        col_rk_detalhes.controls.clear()
        chart_container.content = None

        if eq["saldo"] < 0:
            col_rk_detalhes.controls.append(ft.Text("🚨 DESCLASSIFICADO!", color="#C62828", size=24, weight="bold"))
            col_rk_detalhes.controls.append(ft.Text(
                "A equipe terminou com a Conta Corrente no Vermelho.\nTodos os investimentos foram liquidados para pagar dívidas!",
                color="#333", size=16))
            col_rk_detalhes.controls.append(
                ft.Text(f"Saldo da Conta: {fmt_saldo(eq['saldo'])}", color="#333", size=16, weight="bold"))
            col_rk_detalhes.controls.append(
                ft.Text("Patrimônio Bruto: R$ 0,00", color="#1A237E", size=20, weight="900"))
            chart_container.content = ft.Image(src="Marisela_triste.png", fit="contain", expand=True)
        else:
            col_rk_detalhes.controls.append(
                ft.Text(f"💰 Saldo Conta Corrente: {fmt_saldo(eq['saldo'])}", color="#333", size=16, weight="bold"))
            col_rk_detalhes.controls.append(
                ft.Text("📊 Histórico de Contribuições por Idade:", color="#333", size=16, weight="bold"))
            col_rk_detalhes.controls.append(ft.Text(eq['historico_aportes_txt'], color="#555", size=14))
            col_rk_detalhes.controls.append(
                ft.Text(f"📥 Total Tirado do Bolso: {fmt_saldo(eq['prev_bolso'])}", color="#333", size=16))
            col_rk_detalhes.controls.append(
                ft.Text(f"📈 Juros Compostos Ganhos: {fmt_saldo(eq['prev_juros'])}", color="#43A047", size=16,
                        weight="bold"))
            col_rk_detalhes.controls.append(ft.Container(height=10))
            col_rk_detalhes.controls.append(
                ft.Text(f"👑 PATRIMÔNIO BRUTO:\n{fmt_saldo(eq['patrimonio_total'])}", color="#1A237E", size=24,
                        weight="900"))

            # === GRÁFICO DE LINHA "DESENHADO NA MÃO" (AGORA EXPANDIDO E FORMATADO) ===
            anos_hist = eq["prev_hist"]
            max_y = max(anos_hist) if anos_hist and max(anos_hist) > 0 else 1000

            # Função inteligente para converter em M (Milhão) e k (Mil)
            def formatar_k_m(valor):
                if valor >= 1_000_000:
                    return f"R$ {valor / 1_000_000:.1f} M".replace(".", ",")
                elif valor >= 1_000:
                    return f"R$ {valor / 1_000:.0f} k"
                return f"R$ {int(valor)}"

            # Aumentamos drasticamente as dimensões do gráfico!
            LARGURA = 700
            ALTURA = 360

            pontos_linha = []
            passo = max(1, len(anos_hist) // 300)  # Deixa a curva ainda mais suave

            for m in range(0, len(anos_hist), passo):
                v = anos_hist[m]
                idade = 16 + (m / 12)

                pos_x = (m / len(anos_hist)) * LARGURA
                pos_y = ALTURA - ((v / max_y) * ALTURA)

                pontos_linha.append(
                    ft.Container(
                        width=6, height=6, border_radius=3,
                        bgcolor="#4CAF50",
                        left=pos_x, top=pos_y - 3,
                        tooltip=f"Idade: {idade:.1f} anos\nAcumulado: {fmt_saldo(v)}"
                    )
                )

            eixo_x = ft.Row([
                ft.Text("16a", size=11, color="#999", weight="bold"),
                ft.Container(expand=True),
                ft.Text("28a", size=11, color="#999", weight="bold"),
                ft.Container(expand=True),
                ft.Text("40a", size=11, color="#999", weight="bold"),
                ft.Container(expand=True),
                ft.Text("52a", size=11, color="#999", weight="bold"),
                ft.Container(expand=True),
                ft.Text("65a", size=11, color="#999", weight="bold"),
            ], width=LARGURA)

            # Eixo Y agora usa a nossa função formatar_k_m!
            eixo_y = ft.Column([
                ft.Text(formatar_k_m(max_y), size=12, color="#999", weight="bold"),
                ft.Container(expand=True),
                ft.Text(formatar_k_m(max_y / 2), size=12, color="#999", weight="bold"),
                ft.Container(expand=True),
                ft.Text("R$ 0", size=12, color="#999", weight="bold"),
            ], height=ALTURA, alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

            area_linha = ft.Stack(controls=pontos_linha, width=LARGURA, height=ALTURA)

            grafico_imune = ft.Row([
                eixo_y,
                ft.Column([
                    ft.Container(
                        content=area_linha,
                        width=LARGURA,
                        height=ALTURA,
                        border=ft.Border(bottom=ft.BorderSide(2, "#CCC"), left=ft.BorderSide(2, "#CCC"))
                    ),
                    eixo_x
                ])
            ], spacing=15)

            chart_container.content = ft.Stack([
                ft.Container(content=ft.Image(src="Marisela_alegre.png", opacity=0.15, fit="contain"),
                             alignment=ft.Alignment(0, 0)),
                ft.Column([
                    # Títulos agora perfeitamente centralizados!
                    ft.Container(
                        content=ft.Column([
                            ft.Text("📊 Evolução do Patrimônio (Mês a Mês)", size=22, weight="900", color="#1A237E",
                                    text_align="center"),
                            ft.Text("Passe o mouse sobre a linha para ver os valores exatos de cada mês!", size=14,
                                    color="#555", italic=True, text_align="center"),
                        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2),
                        alignment=ft.Alignment(0, 0), margin=ft.Margin(0, 10, 0, 15)
                    ),
                    grafico_imune
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER)
            ], expand=True)

        # Exibição do Histórico de Escolhas
        list_rk_hist.controls.clear()
        if not eq.get("historico_escolhas"):
            list_rk_hist.controls.append(
                ft.Text("Nenhuma escolha registrada durante o percurso.", size=15, color="#777", italic=True))
        else:
            for item in eq.get("historico_escolhas", []):
                casa = item["casa"]
                texto = item["texto"].replace("\n", " ")
                saldo_imp = item["saldo"]
                inv_imp = item.get("invest")

                imp_str = ""
                if saldo_imp < 0:
                    imp_str += f" (Gastou {fmt_saldo(abs(saldo_imp))})"
                elif saldo_imp > 0:
                    imp_str += f" (Ganhou {fmt_saldo(saldo_imp)})"
                if inv_imp is not None: imp_str += f" [Contribuição: R$ {inv_imp},00/rodada]"

                list_rk_hist.controls.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Text(f"🏠 Casa {casa}:", weight="900", color="#1A237E", size=14),
                            ft.Text(f"{texto}{imp_str}", color="#333", size=14, expand=True)
                        ]),
                        padding=10, bgcolor="#F5F5F5", border_radius=8,
                        border=ft.Border(left=ft.BorderSide(width=3, color="#1A237E"))
                    )
                )

        page.update()

    def avancar_turno():
        if jogo_finalizado[0]: return

        if all(e.get("formado") for e in equipes):
            jogo_finalizado[0] = True
            calcular_ranking_final()
            idx_ranking[0] = len(ranking_calculado) - 1
            exibir_equipe_ranking()

            tela_jogo.visible = False
            tela_ranking.visible = True
            page.update()
            return

        n = len(equipes)
        proximo = (turno_atual[0] + 1) % n

        tentativas = 0
        while equipes[proximo].get("formado") and tentativas < n:
            proximo = (proximo + 1) % n
            tentativas += 1

        turno_atual[0] = proximo
        eq_prox = equipes[proximo]
        cor_prox = dados_jogo.CORES_EQUIPES[proximo % len(dados_jogo.CORES_EQUIPES)]

        lbl_prox_nome.value = eq_prox["nome"]
        lbl_prox_info.value = f"Casa {eq_prox['posicao']}  ·  💰 {fmt_saldo(eq_prox['saldo'])}"
        barra_prox_cor.bgcolor = cor_prox

        card_proxima.scale = 0.8
        card_proxima.opacity = 0
        wrapper_proxima.visible = True
        page.update()

        time.sleep(0.05)
        card_proxima.scale = 1.0
        card_proxima.opacity = 1
        page.update()

    def rk_proximo(e):
        if idx_ranking[0] > 0:
            idx_ranking[0] -= 1
            exibir_equipe_ranking()
        elif idx_ranking[0] == 0:
            lista_resumo_final.controls.clear()
            medalhas = ["🥇", "🥈", "🥉"] + [f"{i + 1}º" for i in range(3, len(ranking_calculado))]

            for i, eq in enumerate(ranking_calculado):
                cor = dados_jogo.CORES_EQUIPES[i % len(dados_jogo.CORES_EQUIPES)]
                val_str = "🚨 DESCLASSIFICADO" if eq["saldo"] < 0 else fmt_saldo(eq["patrimonio_total"])
                cor_val = "#C62828" if eq["saldo"] < 0 else "#2E7D32"

                lista_resumo_final.controls.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Text(medalhas[i], size=20, weight="bold"),
                            ft.Text(f"{eq['nome']} {eq['emojis']}", size=16, color="#1A237E", weight="bold",
                                    expand=True),
                            ft.Text(val_str, size=16, weight="900", color=cor_val)
                        ]),
                        bgcolor="#FAFAFA", border_radius=10, padding=15,
                        border=ft.Border(left=ft.BorderSide(width=5, color=cor))
                    )
                )

            tela_ranking.visible = False
            tela_resumo.visible = True
            page.update()

    def rk_anterior(e):
        if idx_ranking[0] < len(ranking_calculado) - 1:
            idx_ranking[0] += 1
            exibir_equipe_ranking()

    # ==========================================
    # LÓGICA DO SANDBOX (MODO DESENVOLVEDOR)
    # ==========================================
    def abrir_sandbox(e):
        wrapper_sandbox.visible = True
        page.update()

    def aplicar_sandbox(e):
        try:
            passos = int(inp_sandbox.value)
        except:
            passos = 1

        wrapper_sandbox.visible = False
        page.update()

        btn_avancar_dado.data = passos
        aplicar_jogada(None)

    inp_sandbox = ft.TextField(label="Quantas casas pular?", value="1", keyboard_type=ft.KeyboardType.NUMBER)
    wrapper_sandbox = ft.Container(
        content=ft.Container(
            content=ft.Column([
                ft.Text("⚙️ Modo Desenvolvedor", size=20, weight="bold", color="#1A237E"),
                ft.Text("Avance diretamente pelo tabuleiro sem precisar rolar os dados para testar."),
                inp_sandbox,
                ft.Row([ft.TextButton("Cancelar",
                                      on_click=lambda e: setattr(wrapper_sandbox, "visible", False) or page.update()),
                        ft.ElevatedButton("Pular Casas", bgcolor="#1A237E", color="white", on_click=aplicar_sandbox)],
                       alignment=ft.MainAxisAlignment.END)
            ], tight=True, spacing=15),
            width=400, bgcolor="white", border_radius=15, padding=25,
            shadow=ft.BoxShadow(blur_radius=20, color="black26")
        ), alignment=ft.Alignment(0, 0), visible=False, bgcolor="#99000000"
    )

    def fechar_proxima_equipe(e):
        card_proxima.scale = 0.8
        card_proxima.opacity = 0
        page.update()
        time.sleep(0.2)
        wrapper_proxima.visible = False
        atualizar_tela_jogo()

    def aplicar_jogada(e):
        passos = btn_avancar_dado.data
        eq_idx = turno_atual[0]
        eq = equipes[eq_idx]

        pos_anterior = eq["posicao"]
        nova_posicao = min(pos_anterior + passos, TOTAL_CASAS)

        renda_liquida = eq["salario_base"] + eq["renda_extra"] - eq["investimento_turno"]
        eq["saldo"] += renda_liquida

        marcos_cruzados = [m for m in [3, 10, 13, 20, 24, 30] if
                           pos_anterior < m <= nova_posicao and m not in eq["marcos_passados"]]

        eq["posicao"] = nova_posicao
        eq["marcos_passados"].extend(marcos_cruzados)

        card_dado.scale = 0.8
        card_dado.opacity = 0
        page.update()
        time.sleep(0.3)
        wrapper_dado.visible = False
        atualizar_tela_jogo()

        fila_eventos.clear()

        if nova_posicao >= TOTAL_CASAS:
            fila_eventos.append({"tipo": "chegada"})
        elif nova_posicao in EVENTOS_FIXOS:
            ev_fixo = EVENTOS_FIXOS[nova_posicao].copy()
            if ev_fixo.get("regra_ir"):
                if eq.get("investimento_turno", 0) > 0:
                    ev_fixo[
                        "cenario"] = "Hora de acertar as contas com o Leão!\n\nComo você contribuiu ativamente para a Previdência, tem benefício fiscal.\nVocê terá devolução de R$ 6.000,00 que foram descontados no ano anterior!"
                    ev_fixo["saldo"] = 6000.00
                else:
                    ev_fixo[
                        "cenario"] = "Hora de acertar as contas com o Leão!\n\nComo você NÃO contribuiu ativamente para a Previdência, NÃO tem benefício fiscal.\nVocê pagará imposto de R$ 6.000,00."
                    ev_fixo["saldo"] = -6000.00

            ev_fixo["sem_escolha"] = True
            fila_eventos.append({"tipo": "card", "dados": ev_fixo})
        elif nova_posicao in DILEMAS_FIXOS:
            fila_eventos.append({"tipo": "card", "dados": DILEMAS_FIXOS[nova_posicao].copy()})
        else:
            fila_eventos.append({"tipo": "card", "dados": {"titulo": "Dia Tranquilo",
                                                           "cenario": "Nada de novo no front. Apenas avance!",
                                                           "opcoes": [{"texto": "Avançar", "saldo": 0}]}})

        for m in marcos_cruzados:
            fila_eventos.append({"tipo": "marco", "num": m})

        processar_proximo_evento()

    lbl_prox_nome = ft.Text("Equipe", size=28, weight="900", color="white", font_family="Georgia")
    lbl_prox_info = ft.Text("Casa X", size=14, color="#757575")
    barra_prox_cor = ft.Container(height=4, border_radius=2)

    card_proxima = ft.Container(
        content=ft.Column([
            ft.Text("PRÓXIMA EQUIPE", size=11, weight="900", color="#616161"),
            barra_prox_cor,
            lbl_prox_nome,
            lbl_prox_info,
            ft.ElevatedButton("Vamos lá!", bgcolor="#43A047", color="white",
                              style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), padding=15),
                              on_click=fechar_proxima_equipe)
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, alignment=ft.MainAxisAlignment.CENTER),
        width=380, height=240, bgcolor="#212121", border_radius=20, border=ft.Border.all(width=3, color="#424242"),
        padding=20,
        scale=0.8, opacity=0, animate_scale=400, animate_opacity=300
    )
    wrapper_proxima = ft.Container(content=card_proxima, alignment=ft.Alignment(0, 0), visible=False,
                                   bgcolor="#99000000")

    lbl_tipo_evento = ft.Text("DILEMA", size=13, weight="900", color="#F57C00")
    lbl_equipe_evento = ft.Text("Equipe", size=22, weight="900", color="#333")
    lbl_cenario_evento = ft.Text("Cenário", size=20, weight="700", color="#333", font_family="Georgia",
                                 text_align="center")

    lbl_slider_evento = ft.Text("Reajustar Contribuição: R$ 0,00 / rodada", size=16, weight="900", color="#1A237E")
    slider_evento = ft.Slider(min=0, max=19, divisions=19, active_color="#1A237E")

    col_slider_inteira = ft.Container(
        content=ft.Column([
            ft.Text("🎚️ Ajuste sua Previdência Complementar", size=14, color="#555", weight="bold"),
            slider_evento,
            lbl_slider_evento
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5),
        bgcolor="white", padding=20, border_radius=12, border=ft.Border.all(width=2, color="#C5CAE9"), visible=False
    )

    botoes_evento_col = ft.Column(spacing=10, horizontal_alignment=ft.CrossAxisAlignment.STRETCH)

    lbl_resultado_evento = ft.Column(horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5)
    container_resultado = ft.Container(
        content=lbl_resultado_evento,
        bgcolor="#E8F5E9", padding=20, border_radius=12, border=ft.Border.all(width=2, color="#A5D6A7"), visible=False
    )

    btn_avancar_evento = ft.ElevatedButton(
        "Avançar  →", bgcolor="#333", color="white",
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12), padding=20),
        on_click=fechar_evento_passar_fila, visible=False
    )

    card_evento = ft.Container(
        content=ft.Column([
            lbl_tipo_evento,
            lbl_equipe_evento,
            ft.Container(height=10),
            lbl_cenario_evento,
            ft.Container(height=20),
            col_slider_inteira,
            botoes_evento_col,
            container_resultado,
            ft.Container(content=btn_avancar_evento, alignment=ft.Alignment(0, 0),
                         margin=ft.Margin(left=0, top=10, right=0, bottom=0))
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10, tight=True),
        width=650, bgcolor="#FFFDE7", border_radius=22, border=ft.Border.all(width=4, color="#FBC02D"),
        padding=ft.Padding(left=30, top=25, right=30, bottom=30),
        scale=0.8, opacity=0, animate_scale=400, animate_opacity=300,
        shadow=ft.BoxShadow(blur_radius=60, color="black54", offset=ft.Offset(0, 20))
    )
    wrapper_evento = ft.Container(content=card_evento, alignment=ft.Alignment(0, 0), visible=False, bgcolor="#99000000")

    enquete_atual_ref = {}

    def atualizar_botoes_evento(e=None):
        if not enquete_atual_ref: return

        val_puro = int(slider_evento.value) if slider_evento.value else 0
        val_real = calcular_slider_val(val_puro)
        lbl_slider_evento.value = f"Reajustar Contribuição Mensal: R$ {val_real},00 / rodada"

        botoes_evento_col.controls.clear()
        for op in enquete_atual_ref.get("opcoes", []):
            dados_copia = op.copy()
            if "template" in op:
                texto_btn = op["template"].format(val=val_real)
            else:
                texto_btn = op.get("texto", "")

            botoes_evento_col.controls.append(
                ft.ElevatedButton(
                    content=ft.Text(texto_btn, color="white", weight="bold"),
                    bgcolor="#1976D2",
                    style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), padding=15),
                    on_click=lambda e, d=dados_copia: aplicar_consequencia_evento(d)
                )
            )
        if page: page.update()

    slider_evento.on_change = atualizar_botoes_evento

    def mostrar_modal_evento(nome_equipe, enquete):
        nonlocal enquete_atual_ref
        enquete_atual_ref = enquete
        lbl_equipe_evento.value = nome_equipe

        container_resultado.visible = False
        lbl_resultado_evento.visible = False
        btn_avancar_evento.visible = False
        botoes_evento_col.visible = True
        botoes_evento_col.controls.clear()

        is_marco = enquete.get("slider") or enquete.get("titulo") in ["VOCÊ ENTROU NA FACULDADE!",
                                                                      "MERCADO DE TRABALHO"]
        if is_marco:
            card_evento.bgcolor = "#E8EAF6"
            card_evento.border = ft.Border.all(width=4, color="#3F51B5")
            lbl_tipo_evento.color = "#7986CB"
            lbl_equipe_evento.color = "#1A237E"
        else:
            card_evento.bgcolor = "#FFFDE7"
            card_evento.border = ft.Border.all(width=4, color="#FBC02D")
            lbl_tipo_evento.color = "#F57C00"
            lbl_equipe_evento.color = "#333333"

        if enquete.get("sem_escolha"):
            lbl_tipo_evento.value = enquete.get("titulo", "EVENTO!").upper()
            lbl_cenario_evento.value = enquete["cenario"]
            col_slider_inteira.visible = False
            botoes_evento_col.visible = False

            enquete["texto_hist"] = enquete.get("titulo", "Evento Fixo")
            aplicar_consequencia_evento(enquete)
        else:
            lbl_tipo_evento.value = enquete["titulo"].upper()
            lbl_cenario_evento.value = enquete["cenario"]

            if enquete.get("slider"):
                col_slider_inteira.visible = True
                val_atual = enquete.get("valor_atual", 0)
                idx = 0 if val_atual == 0 else int((val_atual - 50) / 50)
                slider_evento.value = max(0, min(19, idx))
            else:
                col_slider_inteira.visible = False

            atualizar_botoes_evento()

        card_evento.scale = 0.8
        card_evento.opacity = 0
        wrapper_evento.visible = True
        page.update()

        time.sleep(0.05)
        card_evento.scale = 1.0
        card_evento.opacity = 1
        page.update()

    # --- O CÉREBRO DO DADO ---
    def abrir_dado(e):
        eq_nome = equipes[turno_atual[0]]["nome"]
        lbl_equipe_dado.value = eq_nome

        if modo_turbo:
            lbl_sub_dado.value = "SUPER DADO 🚀"
            lbl_resultado_dado.color = "#FFCA28"
        else:
            lbl_sub_dado.value = "DADO CLÁSSICO"
            lbl_resultado_dado.color = "white"

        lbl_msg_dado.value = "Sorteando..."
        lbl_msg_dado.color = "#9FA8DA"
        btn_avancar_dado.visible = False

        card_dado.scale = 0.8
        card_dado.opacity = 0
        wrapper_dado.visible = True
        page.update()

        def animar_roleta():
            time.sleep(0.05)
            card_dado.scale = 1.0
            card_dado.opacity = 1
            page.update()

            time.sleep(0.4)
            limite = 9 if modo_turbo else 6

            for i in range(25):
                lbl_resultado_dado.value = str(random.randint(1, limite))
                if i % 2 == 0:
                    lbl_resultado_dado.color = "#FF9800"
                else:
                    lbl_resultado_dado.color = "#FFCA28" if modo_turbo else "white"

                page.update()
                time.sleep(0.06)

            sorteado = random.randint(1, limite)
            lbl_resultado_dado.value = str(sorteado)
            lbl_resultado_dado.color = "#43A047"
            lbl_resultado_dado.scale = 1.2
            page.update()

            time.sleep(0.2)
            lbl_resultado_dado.scale = 1.0
            lbl_msg_dado.value = f"🎉 Tirou {sorteado} casa(s)!"
            lbl_msg_dado.color = "white"

            btn_avancar_dado.data = sorteado
            btn_avancar_dado.visible = True
            page.update()

        threading.Thread(target=animar_roleta, daemon=True).start()

    def confirmar_reiniciar(e):
        equipes.clear()
        atualizar_lista_equipes()
        tela_jogo.visible = False
        tela_sorteio.visible = False
        tela_regras.visible = False
        tela_ranking.visible = False
        tela_resumo.visible = False
        tela_menu.visible = True
        wrapper_reiniciar.visible = False
        page.update()

    def cancelar_reiniciar(e):
        wrapper_reiniciar.visible = False
        page.update()

    wrapper_reiniciar = ft.Container(
        content=ft.Container(
            content=ft.Column([
                ft.Text("Reiniciar Jogo", size=20, weight="900", color="#C62828"),
                ft.Text("Tem certeza que deseja reiniciar o jogo? Você perderá todo o progresso atual.", size=14,
                        color="#333"),
                ft.Row([
                    ft.TextButton("Não", on_click=cancelar_reiniciar),
                    ft.ElevatedButton("Sim, Reiniciar", bgcolor="#C62828", color="white", on_click=confirmar_reiniciar)
                ], alignment=ft.MainAxisAlignment.END)
            ], tight=True, spacing=15),
            width=400, bgcolor="white", border_radius=15, padding=25,
            border=ft.Border.all(width=2, color="#C62828"),
            shadow=ft.BoxShadow(blur_radius=20, color="black26")
        ),
        alignment=ft.Alignment(0, 0), visible=False, bgcolor="#99000000"
    )

    lbl_sub_dado = ft.Text("DADO CLÁSSICO", size=11, weight="900", color="#7986CB", text_align="center")
    lbl_equipe_dado = ft.Text("Equipe X", size=16, weight="700", color="#C5CAE9", text_align="center")
    lbl_resultado_dado = ft.Text("?", size=96, color="white", text_align="center", animate_scale=100)
    lbl_msg_dado = ft.Text("Sorteando...", size=16, weight="700", color="#9FA8DA", text_align="center")

    btn_avancar_dado = ft.ElevatedButton(
        "Avançar  →", bgcolor="#3F51B5", color="white", on_click=aplicar_jogada, visible=False,
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=11), padding=20)
    )

    card_dado = ft.Container(
        content=ft.Column([
            lbl_sub_dado, lbl_equipe_dado, lbl_resultado_dado, lbl_msg_dado, btn_avancar_dado
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5, alignment=ft.MainAxisAlignment.CENTER),
        width=340, height=310, bgcolor="#1A237E", border_radius=24, border=ft.Border.all(width=4, color="#3F51B5"),
        padding=20,
        scale=0.8, opacity=0, animate_scale=400, animate_opacity=300
    )

    wrapper_dado = ft.Container(content=card_dado, alignment=ft.Alignment(0, 0), visible=False, bgcolor="#99000000")

    # ==========================================
    # CONSTRUÇÃO VISUAL DO TABULEIRO E PAINEL
    # ==========================================
    ESP_X = 110
    ESP_Y = 80
    OFFSET_X = 60
    OFFSET_Y = 40
    CASA_TAM = 64
    CENTRO = 32

    caminho_ui = []
    for i in range(TOTAL_CASAS - 1):
        r1, c1 = COORDENADAS[i]
        r2, c2 = COORDENADAS[i + 1]
        x1 = min(c1, c2) * ESP_X + OFFSET_X + CENTRO
        x2 = max(c1, c2) * ESP_X + OFFSET_X + CENTRO
        y1 = min(r1, r2) * ESP_Y + OFFSET_Y + CENTRO
        y2 = max(r1, r2) * ESP_Y + OFFSET_Y + CENTRO

        caminho_ui.append(
            ft.Container(left=x1 - 30, top=y1 - 30, width=(x2 - x1) + 60, height=(y2 - y1) + 60, bgcolor="#BCAAA4",
                         border_radius=30))
        caminho_ui.append(
            ft.Container(left=x1 - 25, top=y1 - 25, width=(x2 - x1) + 50, height=(y2 - y1) + 50, bgcolor="#FFF3E0",
                         border_radius=25))
        caminho_ui.append(
            ft.Container(left=x1 - 3, top=y1 - 3, width=(x2 - x1) + 6, height=(y2 - y1) + 6, bgcolor="#FFCC80",
                         border_radius=3))

    casas_ui = []
    for i in range(TOTAL_CASAS):
        num = i + 1
        r, c = COORDENADAS[i]
        cor = cor_da_casa(num)
        texto = str(num)
        if num % 5 == 0 and num != TOTAL_CASAS: texto = f"★\n{num}"
        if num == 10: texto = f"🎓\n{num}"
        if num == 20: texto = f"💼\n{num}"
        if num in [3, 13, 24, 30]: texto = f"❕\n{num}"

        casa = ft.Container(
            content=ft.Text(texto, weight="900", size=16 if "\n" in texto else 22, color="white", text_align="center"),
            width=CASA_TAM, height=CASA_TAM, bgcolor=cor, border_radius=14,
            border=ft.Border(top=ft.BorderSide(width=4, color="white"), bottom=ft.BorderSide(width=4, color="white"),
                             left=ft.BorderSide(width=4, color="white"), right=ft.BorderSide(width=4, color="white")),
            alignment=ft.Alignment(0, 0), left=c * ESP_X + OFFSET_X, top=r * ESP_Y + OFFSET_Y,
            shadow=ft.BoxShadow(blur_radius=8, color="black38", offset=ft.Offset(2, 4))
        )
        casas_ui.append(casa)

    tabuleiro_stack = ft.Stack(
        controls=caminho_ui + casas_ui + [
            camada_pinos,
            ft.Container(content=ft.Image(src="Marisela_binoculo.png", height=320, fit="contain"), bottom=-10,
                         left=-10),
            ft.Container(content=ft.Row(
                [ft.Image(src="logo_agros.png", height=45), ft.Image(src="logo_ENEF.png", height=45),
                 ft.Image(src="logo_abrapp.png", height=45), ft.Image(src="logo_UniAbrapp.png", height=45)],
                spacing=15), bottom=20, right=20)
        ], expand=True
    )

    # ==========================================
    # PAINEL LATERAL E BARRA SUPERIOR
    # ==========================================
    def abrir_ajuda_tabuleiro(e):
        wrapper_ajuda_tab.visible = True; page.update()

    def fechar_ajuda_tabuleiro(e):
        wrapper_ajuda_tab.visible = False; page.update()

    barra_topo = ft.Container(
        height=50, bgcolor="#212121", padding=ft.Padding(left=20, top=0, right=20, bottom=0),
        content=ft.Row([
            ft.Text("O JOGO DA VIDA  ·  EDUCAÇÃO FINANCEIRA E PREVIDENCIÁRIA", size=14, weight="900", color="white"),
            ft.Container(expand=True),
            ft.ElevatedButton("Como Funciona o Tabuleiro?", bgcolor="#FF9800", color="white",
                              style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8), padding=10),
                              on_click=abrir_ajuda_tabuleiro)
        ])
    )

    card_vez = ft.Container(
        bgcolor="#212121", border_radius=14, padding=15,
        content=ft.Column(
            [ft.Text("VEZ DE JOGAR", size=10, weight="900", color="#616161", text_align="center"), lbl_vez_nome,
             barra_cor_vez], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5)
    )

    painel_lateral = ft.Container(
        width=260, bgcolor="#FAFAFA", padding=20, border=ft.Border(left=ft.BorderSide(width=2, color="#E0E0E0")),
        content=ft.Column([
            card_vez, ft.Container(height=10), ft.Text("PLACAR DAS EQUIPES", size=11, weight="900", color="#999"),
            lista_placar,
            ft.ElevatedButton("🎲 Girar Dado", bgcolor="#43A047", color="white",
                              style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), padding=15),
                              on_click=abrir_dado),
            ft.Container(content=ft.Text("⚙️ Teste", color="#999"), alignment=ft.Alignment(0, 0),
                         on_click=abrir_sandbox),
            ft.ElevatedButton("↩ Reiniciar Jogo", bgcolor="#EEEEEE", color="#9E9E9E",
                              style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), padding=15),
                              on_click=lambda e: setattr(wrapper_reiniciar, "visible", True) or page.update())
        ], horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
    )

    card_ajuda_tab = ft.Container(
        content=ft.Column([
            ft.Text("🧭 Entendendo o Tabuleiro", size=20, weight="900", color="#1A237E"),
            ft.Text(spans=[
                ft.TextSpan(
                    "A tela do jogo é dividida entre o Tabuleiro (à esquerda) e o Painel de Controle (à direita).\n\n"),
                ft.TextSpan("🎲 Como Jogar:\n", ft.TextStyle(weight="bold")), ft.TextSpan(
                    "Tudo acontece no painel da direita! Basta o jogador da vez clicar no botão verde \"🎲 Girar Dado\" para sortear e se mover pelo tabuleiro. A cada jogada, os eventos aparecem na tela para o jogador tomar as decisões.\n\n"),
                ft.TextSpan("👤 De quem é a vez?\n", ft.TextStyle(weight="bold")), ft.TextSpan(
                    "O topo do painel lateral sempre mostra em destaque o nome do jogador da vez. Além disso, na lista de jogadores logo abaixo, o cartão de quem é a vez fica destacado com fundo cinza e borda colorida.\n\n"),
                ft.TextSpan("💰 Saldo (A sua Conta Corrente):\n", ft.TextStyle(weight="bold")), ft.TextSpan(
                    "Ele mostra exatamente o dinheiro vivo que o jogador ou a equipe têm no momento para gastar nos dilemas ou pagar contas.\n\n"),
                ft.TextSpan("🔄 Renda (+0,00/rod):\n", ft.TextStyle(weight="bold")), ft.TextSpan(
                    "Essa é a sua Renda! Mostra quanto dinheiro \"cai\" na sua conta a cada rodada (giro do dado). Esse valor é calculated assim: (Salário Base + Rendas Extras) - (O que você investe na Previdência) = Renda Disponível. Atenção: Se você investir muito sem ter salário, essa renda pode ficar negativa!\n\n"),
                ft.TextSpan("🏠 A Casa 0:\n", ft.TextStyle(weight="bold")), ft.TextSpan(
                    "Todo jogador começa na Casa 0! Ela não existe fisicamente no desenho do tabuleiro. Significa apenas que você está na \"Linha de Partida\" aguardando o seu primeiro giro de dado."),
            ], size=14, color="#333"),
            ft.Container(content=ft.ElevatedButton("Entendi!", bgcolor="#FF9800", color="white",
                                                   on_click=fechar_ajuda_tabuleiro), alignment=ft.Alignment(0, 0),
                         margin=ft.Margin(left=0, top=10, right=0, bottom=0))
        ], horizontal_alignment=ft.CrossAxisAlignment.START, scroll=ft.ScrollMode.AUTO, spacing=10),
        width=550, height=450, bgcolor="white", border_radius=15, padding=25,
        border=ft.Border(top=ft.BorderSide(width=2, color="#1A237E"), bottom=ft.BorderSide(width=2, color="#1A237E"),
                         left=ft.BorderSide(width=2, color="#1A237E"), right=ft.BorderSide(width=2, color="#1A237E")),
        shadow=ft.BoxShadow(blur_radius=20, color="black26")
    )
    wrapper_ajuda_tab = ft.Container(content=card_ajuda_tab, alignment=ft.Alignment(0, 0), visible=False)

    conteudo_jogo = ft.Column([barra_topo, ft.Row(
        [ft.Container(content=tabuleiro_stack, expand=True, bgcolor="#ECEFF1"), painel_lateral], expand=True,
        spacing=0)], expand=True, spacing=0)

    tela_jogo = ft.Stack([
        conteudo_jogo, wrapper_ajuda_tab, wrapper_reiniciar, wrapper_sandbox,
        wrapper_dado, wrapper_evento, wrapper_proxima
    ], expand=True, visible=False)

    # ==========================================
    # TELAS FINAIS DE RANKING E RESULTADO
    # ==========================================
    lbl_rk_pos = ft.Text("POSIÇÃO", size=20, weight="900", color="#999")
    lbl_rk_nome = ft.Text("Nome Equipe", size=36, weight="900", color="#1A237E", font_family="Georgia")
    col_rk_detalhes = ft.Column(spacing=5, scroll=ft.ScrollMode.AUTO, expand=True)

    chart_container = ft.Container(expand=True, bgcolor="#FAFAFA", border_radius=10,
                                   border=ft.Border.all(width=2, color="#E0E0E0"), padding=10)
    list_rk_hist = ft.ListView(expand=True, spacing=10)

    hist_container = ft.Container(content=list_rk_hist, padding=10, expand=True, visible=False, bgcolor="white",
                                  border_radius=10, border=ft.Border.all(width=2, color="#E0E0E0"))

    btn_tab_grafico = ft.ElevatedButton(content=ft.Text("📊 Gráfico de Evolução"), expand=1, bgcolor="#3F51B5",
                                        color="white",
                                        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=4), padding=15))
    btn_tab_hist = ft.ElevatedButton(content=ft.Text("📜 Histórico de Escolhas"), expand=1, bgcolor="#7986CB",
                                     color="white",
                                     style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=4), padding=15))

    def switch_tab(tab_name):
        if tab_name == "grafico":
            chart_container.visible = True
            hist_container.visible = False
            btn_tab_grafico.bgcolor = "#3F51B5"
            btn_tab_hist.bgcolor = "#7986CB"
        else:
            chart_container.visible = False
            hist_container.visible = True
            btn_tab_grafico.bgcolor = "#7986CB"
            btn_tab_hist.bgcolor = "#3F51B5"
        if page: page.update()

    btn_tab_grafico.on_click = lambda e: switch_tab("grafico")
    btn_tab_hist.on_click = lambda e: switch_tab("hist")

    tabs_customizados = ft.Column([
        ft.Row([btn_tab_grafico, btn_tab_hist], spacing=2),
        chart_container, hist_container
    ], expand=True)

    # === BOTÕES ROBUSTOS E ALINHADOS DA TELA DE RESULTADOS ===
    btn_rk_prev = ft.ElevatedButton("⬅️ Voltar", bgcolor="#E0E0E0", color="#424242",
                                    style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8), padding=18),
                                    expand=True, on_click=rk_anterior)
    btn_rk_next = ft.ElevatedButton("Avançar ➡️", bgcolor="#FF9800", color="white",
                                    style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8), padding=18),
                                    expand=True, on_click=rk_proximo)

    tela_ranking = ft.Container(
        bgcolor="#1A237E", expand=True, padding=40, visible=False,
        content=ft.Container(
            bgcolor="white", border_radius=20, padding=30,
            content=ft.Row([
                ft.Column([
                    lbl_rk_pos, lbl_rk_nome, col_rk_detalhes,
                    # Botões esticados e alinhados perfeitamente
                    ft.Row([btn_rk_prev, btn_rk_next], spacing=10),
                    ft.Row([ft.ElevatedButton("Finalizar Jogo 🏁", bgcolor="#E53935", color="white",
                                              style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8),
                                                                   padding=18), expand=True,
                                              on_click=lambda e: setattr(wrapper_reiniciar, "visible",
                                                                         True) or page.update())])
                ], expand=1),
                ft.Container(content=tabs_customizados, expand=2)
            ], expand=True, spacing=20)
        )
    )

    lista_resumo_final = ft.ListView(expand=True, spacing=12)

    tela_resumo = ft.Container(
        bgcolor="#F5F5F5", expand=True, visible=False, alignment=ft.Alignment(0, 0),
        content=ft.Container(
            bgcolor="white", border_radius=20, border=ft.Border.all(width=1, color="#E0E0E0"), padding=40, width=650,
            height=500,
            content=ft.Column([
                ft.Text("🏆 Classificação Geral Final", size=28, weight="900", color="#1A237E", font_family="Georgia",
                        text_align="center"),
                lista_resumo_final,
                ft.ElevatedButton("Finalizar e Voltar ao Início", bgcolor="#1A237E", color="white",
                                  style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12), padding=15),
                                  on_click=lambda e: confirmar_reiniciar(None))
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        )
    )

    # ==========================================
    # TELAS INICIAIS, DE REGRAS E FUNÇÕES DO MENU
    # ==========================================

    def fechar_card(e):
        wrapper_instrucoes.visible = False; page.update()

    def abrir_card(e):
        wrapper_instrucoes.visible = True; page.update()

    def ir_para_sorteio(e):
        nonlocal ordem_final
        sorteado = sorted([(n, random.randint(1, 6)) for n in equipes], key=lambda x: -x[1])
        ordem_final = [s[0] for s in sorteado]

        medalhas = ["🥇", "🥈", "🥉"] + [f"{i + 1}º" for i in range(3, len(ordem_final))]
        lista_sorteio.controls.clear()

        for i, nome in enumerate(ordem_final):
            cor = dados_jogo.CORES_EQUIPES[i % len(dados_jogo.CORES_EQUIPES)]
            linha = ft.Container(
                content=ft.Row([ft.Text(medalhas[i], size=22, weight="bold"),
                                ft.Text(nome, size=15, weight="bold", color="#555")]),
                bgcolor="#FAFAFA" if i > 0 else "#F5F5F5", border_radius=12, padding=10,
                border=ft.Border(left=ft.BorderSide(width=4, color=cor),
                                 top=ft.BorderSide(width=0, color="transparent"),
                                 right=ft.BorderSide(width=0, color="transparent"),
                                 bottom=ft.BorderSide(width=0, color="transparent"))
            )
            lista_sorteio.controls.append(linha)

        tela_menu.visible = False
        tela_sorteio.visible = True
        page.update()

    def ir_para_regras(e):
        tela_sorteio.visible = False
        tela_regras.visible = True
        page.update()

    def atualizar_lista_equipes():
        lista_equipes.controls.clear()
        for i, nome in enumerate(equipes):
            cor = dados_jogo.CORES_EQUIPES[i % len(dados_jogo.CORES_EQUIPES)]
            btn_remover = ft.Container(content=ft.Text("✕", size=14, weight="bold", color="#BDBDBD"), padding=5,
                                       on_click=lambda e, n=nome: remover_equipe(n))
            linha = ft.Container(
                content=ft.Row(
                    [ft.Text(nome, weight="bold", color="#1A237E", size=16, font_family="Georgia", expand=True),
                     btn_remover]),
                bgcolor="#FAFAFA", border_radius=10, padding=10,
                border=ft.Border(left=ft.BorderSide(width=4, color=cor),
                                 top=ft.BorderSide(width=0, color="transparent"),
                                 right=ft.BorderSide(width=0, color="transparent"),
                                 bottom=ft.BorderSide(width=0, color="transparent"))
            )
            lista_equipes.controls.append(linha)
        btn_sortear.disabled = len(equipes) < 2
        page.update()

    def adicionar_equipe(e):
        nome = tf_nome.value.strip()
        if nome and nome not in equipes:
            equipes.append(nome)
            tf_nome.value = ""
            atualizar_lista_equipes()

    def remover_equipe(nome):
        equipes.remove(nome)
        atualizar_lista_equipes()

    def set_modo_turbo(e, valor):
        nonlocal modo_turbo
        modo_turbo = valor
        if modo_turbo:
            btn_classico.bgcolor = "#EEEEEE";
            btn_classico.color = "#9E9E9E";
            btn_turbo.bgcolor = "#FF8F00";
            btn_turbo.color = "white"
            lbl_desc_modo.value = "O tempo voa! Partidas mais curtas, pulos longos e uma jornada bem mais rápida!"
        else:
            btn_classico.bgcolor = "#1976D2";
            btn_classico.color = "white";
            btn_turbo.bgcolor = "#EEEEEE";
            btn_turbo.color = "#9E9E9E"
            lbl_desc_modo.value = "Um jogo cadenciado. Caminhe passo a passo e viva mais eventos do tabuleiro."
        page.update()

    lbl_desc_modo = ft.Text("Um jogo cadenciado. Caminhe passo a passo e viva mais eventos do tabuleiro.", size=13,
                            color="#757575", italic=True, text_align="center")
    btn_classico = ft.ElevatedButton(content=ft.Text("🎲 Modo Clássico\n(Dado 1 a 6)", text_align="center"),
                                     on_click=lambda e: set_modo_turbo(e, False), bgcolor="#1976D2", color="white",
                                     style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), padding=15),
                                     expand=True)
    btn_turbo = ft.ElevatedButton(content=ft.Text("🚀 Modo Turbo\n(Dado 1 a 9)", text_align="center"),
                                  on_click=lambda e: set_modo_turbo(e, True), bgcolor="#EEEEEE", color="#9E9E9E",
                                  style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), padding=15),
                                  expand=True)

    tf_nome = ft.TextField(hint_text="Defina seu nome...", bgcolor="#1A237E", color="white", border_radius=10,
                           expand=True, border_color="#C5CAE9", border_width=2, hint_style=ft.TextStyle(color="white"),
                           on_submit=lambda e: adicionar_equipe(e))
    lista_equipes = ft.ListView(expand=True, spacing=10, auto_scroll=True)
    btn_sortear = ft.ElevatedButton("🎲 Sortear Ordem do Jogo", disabled=True, bgcolor="#1A237E", color="white",
                                    style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=13), padding=15),
                                    on_click=ir_para_sorteio)
    btn_adicionar_eq = ft.Container(content=ft.Text("+", size=24, weight="900", color="white"), bgcolor="#3F51B5",
                                    width=44, height=44, border_radius=10, alignment=ft.Alignment(0, 0),
                                    on_click=lambda e: adicionar_equipe(e))

    card_menu = ft.Container(
        content=ft.Column([
            ft.Row([ft.Image(src="logo_agros.png", height=40), ft.Image(src="logo_ENEF.png", height=40),
                    ft.Image(src="logo_abrapp.png", height=40), ft.Image(src="logo_UniAbrapp.png", height=40)],
                   alignment=ft.MainAxisAlignment.CENTER, spacing=40),
            ft.Text("O Jogo da Vida", size=30, weight="900", color="#1A237E", text_align="center",
                    font_family="Georgia"),
            ft.Text("EDUCAÇÃO FINANCEIRA E PREVIDENCIÁRIA", size=12, weight="bold", color="#3F51B5",
                    text_align="center"),
            ft.Row([tf_nome, btn_adicionar_eq]),
            ft.Container(content=lista_equipes, height=200),
            ft.Container(expand=True),
            ft.Row([ft.Container(content=btn_sortear, expand=True)], alignment=ft.MainAxisAlignment.CENTER)
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=15),
        width=500, height=620, bgcolor="white", border_radius=20, padding=40,
        border=ft.Border(top=ft.BorderSide(width=1, color="#E0E0E0"), bottom=ft.BorderSide(width=1, color="#E0E0E0"),
                         left=ft.BorderSide(width=1, color="#E0E0E0"), right=ft.BorderSide(width=1, color="#E0E0E0")),
        shadow=ft.BoxShadow(blur_radius=10, color="black12")
    )

    card_instrucoes = ft.Container(
        content=ft.Column([
            ft.Container(
                content=ft.Text("🚀 Como Iniciar?", size=22, weight="900", color="#1A237E", font_family="Georgia"),
                alignment=ft.Alignment(0, 0), margin=ft.Margin(left=0, top=0, right=0, bottom=5)),
            ft.Text(spans=[ft.TextSpan("Bem-vindo ao "),
                           ft.TextSpan("Jogo da Vida: Educação Financeira e Previdenciária!",
                                       ft.TextStyle(weight="bold")),
                           ft.TextSpan(" Para iniciar a sua jornada, siga estes passos simples:")], size=15,
                    color="#333"),
            ft.Text(spans=[ft.TextSpan("• Digite o nome do jogador ou da equipe no campo de texto! "),
                           ft.TextSpan("“Defina seu nome...”", ft.TextStyle(weight="bold")), ft.TextSpan(".")], size=15,
                    color="#333"),
            ft.Text(spans=[ft.TextSpan("• Clique no botão "), ft.TextSpan("'+'", ft.TextStyle(weight="bold")),
                           ft.TextSpan(" para adicionar o jogador.")], size=15, color="#333"),
            ft.Text(spans=[ft.TextSpan("• Repita o processo até que "),
                           ft.TextSpan("pelo menos 2 jogadores", ft.TextStyle(weight="bold")),
                           ft.TextSpan(" estejam cadastrados.")], size=15, color="#333"),
            ft.Text(spans=[ft.TextSpan("• Quando todos estiverem na lista, clique no botão azul "),
                           ft.TextSpan("'🎲 Sortear Ordem do Jogo'", ft.TextStyle(weight="bold")), ft.TextSpan(".")],
                    size=15, color="#333"),
            ft.Text(
                "Não se preocupe, na próxima tela você terá acesso ao Manual Completo com todas as regras do jogo antes de rolar os dados!",
                size=14, color="#555"),
            ft.Container(content=ft.ElevatedButton("Entendi!", bgcolor="#FF9800", color="white",
                                                   style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8),
                                                                        padding=15), on_click=fechar_card),
                         alignment=ft.Alignment(0, 0), margin=ft.Margin(left=0, top=10, right=0, bottom=0))
        ], horizontal_alignment=ft.CrossAxisAlignment.START, spacing=8, tight=True),
        width=520, height=440, bgcolor="white", border_radius=15, padding=30,
        border=ft.Border(top=ft.BorderSide(width=2, color="#1A237E"), bottom=ft.BorderSide(width=2, color="#1A237E"),
                         left=ft.BorderSide(width=2, color="#1A237E"), right=ft.BorderSide(width=2, color="#1A237E")),
        shadow=ft.BoxShadow(blur_radius=20, color="black26")
    )
    wrapper_instrucoes = ft.Container(content=card_instrucoes, alignment=ft.Alignment(0, 0), visible=False)

    tela_menu = ft.Stack([
        ft.Row([
            ft.Container(content=ft.ElevatedButton("Como Começar?", bgcolor="#1A237E", color="white",
                                                   style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=15),
                                                                        padding=20), on_click=abrir_card),
                         alignment=ft.Alignment(-1, -1), padding=40, expand=True),
            ft.Container(content=card_menu, alignment=ft.Alignment(0, 0)),
            ft.Container(content=ft.Image(src="Marisela_olho.png", height=650, fit="contain"),
                         alignment=ft.Alignment(1, 1), expand=True)
        ], alignment=ft.MainAxisAlignment.CENTER, expand=True), wrapper_instrucoes
    ], expand=True)

    lista_sorteio = ft.ListView(expand=True, spacing=10)
    card_sorteio = ft.Container(
        content=ft.Column([
            ft.Text("Ordem definida!", size=26, weight="900", color="#1A237E", font_family="Georgia"),
            ft.Container(content=lista_sorteio, height=200),
            ft.Text("⚙️ Escolha a Dinâmica do Jogo:", weight="bold", color="#555"),
            ft.Row([btn_classico, btn_turbo], alignment=ft.MainAxisAlignment.CENTER, spacing=15),
            ft.Container(content=lbl_desc_modo, padding=ft.Padding(left=0, top=0, right=0, bottom=10)),
            ft.Row([ft.ElevatedButton("🚀 Ver Regras do Jogo!", bgcolor="#1A237E", color="white",
                                      style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), padding=15),
                                      on_click=ir_para_regras, expand=True)])
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, tight=True),
        width=550, bgcolor="white", border_radius=20, padding=40, shadow=ft.BoxShadow(blur_radius=10, color="black12")
    )
    tela_sorteio = ft.Stack([ft.Container(content=card_sorteio, alignment=ft.Alignment(0, 0))], expand=True,
                            visible=False)

    def abrir_manual(e):
        wrapper_manual.visible = True; page.update()

    def fechar_manual(e):
        wrapper_manual.visible = False; page.update()

    header_regras = ft.Row([
        ft.Text("📜 Como Funciona o Jogo?", size=26, weight="900", color="#1A237E", font_family="Georgia"),
        ft.Container(expand=True),
        ft.ElevatedButton("Manual Completo", bgcolor="#FF9800", color="white",
                          style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8), padding=15),
                          on_click=abrir_manual)
    ])

    corpo_regras = ft.Container(
        content=ft.Column([
            ft.Text(spans=[ft.TextSpan("O "), ft.TextSpan("Jogo da Vida", ft.TextStyle(weight="bold")), ft.TextSpan(
                " simula a jornada financeira dos 16 aos 65 anos. O objetivo é simular escolhas no decorrer da vida e pensar em atitudes na vida real que possam contribuir para chegar à aposentadoria com o maior patrimônio possível!")],
                    size=15, color="#333"),
            ft.Text("🧭 O Básico para Começar:", size=16, weight="bold", color="#333"),
            ft.Text(spans=[ft.TextSpan("• Cada jogador inicia a partida com "),
                           ft.TextSpan("R$ 1.621,00", ft.TextStyle(weight="bold")), ft.TextSpan(".")], size=14,
                    color="#333"),
            ft.Text(spans=[ft.TextSpan("• Ao longo do tabuleiro, enfrentará dilemas financeiros. Seja sincero: "),
                           ft.TextSpan("o que você faria na vida real?", ft.TextStyle(weight="bold"))], size=14,
                    color="#333"),
            ft.Text(spans=[ft.TextSpan("• Fique atento às "),
                           ft.TextSpan("Casas Especiais (!)", ft.TextStyle(weight="bold")),
                           ft.TextSpan(": Elas representam "),
                           ft.TextSpan("Marcos de Vida", ft.TextStyle(weight="bold")), ft.TextSpan(
                    " aos 16, 20, 30 e 45 anos, momentos fundamentais para investir na Previdência Complementar e na Educação.")],
                    size=14, color="#333"),
            ft.Text("⭐ Os Emojis e as Regras:", size=16, weight="bold", color="#333"),
            ft.Text(
                "Suas escolhas rendem Emojis no seu placar. Eles representam a evolução da sua vida financeira e trazem benefícios reais para a sua partida:",
                size=14, color="#333"),
            ft.Text(spans=[ft.TextSpan("• 🏦 "), ft.TextSpan("Previdência: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan("Faz seu dinheiro render juros compostos de 1% ao mês até o fim do jogo.")],
                    size=14, color="#333"),
            ft.Text(spans=[ft.TextSpan("• 📚 "), ft.TextSpan("Educação: ", ft.TextStyle(weight="bold")), ft.TextSpan(
                "Quanto mais livros juntar na juventude, maior será o seu salário inicial ao se formar!")], size=14,
                    color="#333"),
            ft.Text(spans=[ft.TextSpan("• 👵 "), ft.TextSpan("Vovó: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan("Garante uma mesada extra de "),
                           ft.TextSpan("R$ 200,00/rodada", ft.TextStyle(weight="bold")),
                           ft.TextSpan(" (mas acaba quando você conseguir um emprego).")], size=14, color="#333"),
            ft.Text(spans=[ft.TextSpan("• 💼 "), ft.TextSpan("Mercado de Trabalho: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan(
                               "Você se formou! Agora sua renda aumenta e você ganha seu salário a cada rodada.")],
                    size=14, color="#333"),
            ft.Text(
                spans=[ft.TextSpan("• 📈/🎓 "), ft.TextSpan("Capacitação e Pós-Graduação: ", ft.TextStyle(weight="bold")),
                       ft.TextSpan("Aumentam o seu salário base permanentemente!")], size=14, color="#333"),
            ft.Container(
                content=ft.Column([
                    ft.Text("🚨 REGRA DE OURO:", weight="900", color="#C62828", size=14),
                    ft.Text(spans=[
                        ft.TextSpan("Cuidado com os excessos! Quem terminar o jogo com a Conta Corrente no vermelho "),
                        ft.TextSpan("perde todos os investimentos", ft.TextStyle(weight="bold")),
                        ft.TextSpan(" para pagar as dívidas e é desclassificado da partida.")], color="#D32F2F",
                            size=14)
                ], spacing=2),
                bgcolor="#FFEBEE", border=ft.Border(left=ft.BorderSide(width=5, color="#D32F2F")), padding=12,
                border_radius=5, margin=ft.Margin(left=0, top=10, right=0, bottom=0)
            )
        ], spacing=10, scroll=ft.ScrollMode.AUTO), height=350, padding=ft.Padding(left=0, top=0, right=15, bottom=0)
    )

    # === A FUNÇÃO QUE HAVIA SIDO APAGADA VOLTA AQUI ===
    def iniciar_jogo(e):
        equipes.clear()
        for nome in ordem_final:
            equipes.append({
                "nome": nome, "saldo": 1621, "posicao": 0, "formado": False, "salario_base": 0,
                "renda_extra": 0, "investimento_turno": 0, "qtd_livros": 0, "tem_mesada_vo": False,
                "emojis": "", "marcos_passados": [], "historico_escolhas": []
            })
        turno_atual[0] = 0
        jogo_finalizado[0] = False
        formados.clear()
        fila_eventos.clear()
        atualizar_tela_jogo()

        tela_regras.visible = False
        tela_jogo.visible = True
        page.update()

    # === O CARD COM O BOTÃO PUXANDO A FUNÇÃO ACIMA ===
    card_regras = ft.Container(
        content=ft.Column([
            header_regras, corpo_regras,
            ft.Row([ft.ElevatedButton("Entendi, vamos para o Tabuleiro! 🚀", bgcolor="#43A047", color="white",
                                      style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), padding=20),
                                      on_click=iniciar_jogo, expand=True)])
        ], spacing=20, tight=True),
        width=850, bgcolor="white", border_radius=20, padding=40, shadow=ft.BoxShadow(blur_radius=10, color="black12")
    )

    corpo_manual = ft.Container(
        content=ft.Column([
            ft.Text("CARDS JOGO DA VIDA: EDUCAÇÃO FINANCEIRA E PREVIDENCIÁRIA", size=14, color="#1A237E",
                    weight="bold"),
            ft.Text("“Como funciona o jogo?”", size=14, color="#555", weight="bold", italic=True),
            ft.Text(
                "O jogo simula a vida dos participantes com escolhas financeiras e previdenciárias ao longo dos 16 aos 65 anos. As escolhas feitas vão interferir na qualidade de vida.\n\nDurante a jornada até a aposentadoria, o jogador passará por marcos fundamentais, em que precisará fazer escolhas que serão determinantes para o futuro. As escolhas estão relacionadas a investimentos, educação e saúde.\n\nA duração do jogo depende da quantidade de jogadores, mas a estimativa média é de 30 minutos.",
                size=14, color="#333"),
            ft.Divider(color="#E0E0E0", height=20),
            ft.Text("Como Começar", size=16, color="#1A237E", weight="bold"),
            ft.Text(
                "É necessário no mínimo dois jogadores. Cada jogador pode ser uma única pessoa ou uma equipe, como por exemplo, um grupo de amigos.\n\nApós registrar o jogador ou da equipe na caixinha “Defina seu nome…”, cada jogador deve clicar em +. Assim que todos os jogadores estiverem registrados, deve-se clicar em “sortear a ordem do jogo”. Aparecerá a ordem que os participantes jogarão. Ao clicar em ver regras do jogo, a próxima tela trará informações sobre o funcionamento do jogo. Entendidas as regras, o jogador deve clicar em “vamos para o tabuleiro para começar a jogar”.",
                size=14, color="#333"),
            ft.Container(content=ft.Text(spans=[ft.TextSpan("Lembrete: ", ft.TextStyle(weight="bold")), ft.TextSpan(
                "Os jogadores deverão ser sinceros nas respostas, e escolher as opções que realmente fariam, pois o jogo tende a simular sobre a educação financeira e previdenciária na vida real.")],
                                         size=14, color="#333"), bgcolor="#FFF3E0", padding=10, border_radius=5,
                         border=ft.Border(left=ft.BorderSide(width=4, color="#FF9800"))),
            ft.Divider(color="#E0E0E0", height=20),
            ft.Text("Princípios do Jogo", size=16, color="#1A237E", weight="bold"),
            ft.Text(spans=[ft.TextSpan("Cada jogador inicia com "),
                           ft.TextSpan("1 salário mínimo ", ft.TextStyle(weight="bold")),
                           ft.TextSpan("vigente em 2026, o que corresponde ao valor de "),
                           ft.TextSpan("R$ 1.621,00", ft.TextStyle(weight="bold")), ft.TextSpan(".")], size=14,
                    color="#333"),
            ft.Text(
                "O saldo em conta, renda e emojis conquistados no decorrer do jogo aparecerão no lado direito da tela. Os emojis são:",
                size=14, color="#333"),
            ft.Text(spans=[ft.TextSpan("• 🏦 "),
                           ft.TextSpan("Investimento na Previdência Complementar: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan(
                               "Todo dinheiro investido é um cuidado pessoal e um passo importante em direção ao futuro financeiro mais seguro e tranquilo. Ao fazer a escolha de investir em Previdência Complementar, o dinheiro será aplicado a uma taxa de juros compostos, projetada em "),
                           ft.TextSpan("1% ao mês", ft.TextStyle(weight="bold")), ft.TextSpan(".")], size=14,
                    color="#333"),
            ft.Text(spans=[ft.TextSpan("• 📚 "), ft.TextSpan("Investimento em Educação: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan(
                               "Cursos, livros e treinamentos geram conhecimento acumulado e contribuem para aumentar o salário quando o jogador entrar para o mercado de trabalho.")],
                    size=14, color="#333"),
            ft.Text(spans=[ft.TextSpan("• 👵 "), ft.TextSpan("Vovó: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan("Se a vovó der mesada para o jogador, ele ganha "),
                           ft.TextSpan("R$ 200,00 extra por rodada", ft.TextStyle(weight="bold")), ft.TextSpan(
                    ". Mas atenção: a mesada acaba assim que o jogador entrar no mercado de trabalho!")], size=14,
                    color="#333"),
            ft.Text(spans=[ft.TextSpan("• Faculdade: ", ft.TextStyle(weight="bold")), ft.TextSpan(
                "Independente da área que o jogador for seguir, o salário inicial terá o mesmo valor. Assim que ele se formar, ganhará um emoji. As áreas que podem ser escolhidas são:")],
                    size=14, color="#333"),
            ft.Text(spans=[ft.TextSpan("   🌾 "), ft.TextSpan("Agrárias: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan("Focadas no cultivo, agronegócio e produção de alimentos.")], size=14,
                    color="#333"),
            ft.Text(spans=[ft.TextSpan("   🧬 "), ft.TextSpan("Biológicas: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan("Focadas no bem-estar físico, animal e ecossistemas.")], size=14, color="#333"),
            ft.Text(spans=[ft.TextSpan("   💻 "), ft.TextSpan("Exatas: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan("Voltadas para números, lógica, dados e infraestrutura.")], size=14,
                    color="#333"),
            ft.Text(spans=[ft.TextSpan("   🎭 "), ft.TextSpan("Humanas: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan("Focadas no comportamento, na sociedade, leis e mercados.")], size=14,
                    color="#333"),
            ft.Text(spans=[ft.TextSpan("• 🎓 "), ft.TextSpan("Pós-Graduação: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan(
                               "É uma especialização que permite a ampliação do conhecimento, o que aumenta o salário do jogador.")],
                    size=14, color="#333"),
            ft.Text(spans=[ft.TextSpan("• 📈 "), ft.TextSpan("Capacitação: ", ft.TextStyle(weight="bold")), ft.TextSpan(
                "É uma capacitação profissional, que também possibilita a ampliação do conhecimento, o que também aumenta o salário do jogador.")],
                    size=14, color="#333"),
            ft.Text(spans=[ft.TextSpan("• 💼 "), ft.TextSpan("Maleta: ", ft.TextStyle(weight="bold")),
                           ft.TextSpan("Indica que o jogador começou a receber seu salário profissional.")], size=14,
                    color="#333"),
            ft.Text(
                "No canto direito do tabuleiro, o jogador acompanha o placar do jogo, os emojis conquistados, a renda e o saldo da sua conta corrente.",
                size=14, color="#333"),
            ft.Container(content=ft.Text(spans=[ft.TextSpan("🚨 CUIDADO: ", ft.TextStyle(weight="bold")), ft.TextSpan(
                "Quem terminar o jogo com a Conta Corrente no vermelho (negativa) perde todos os investimentos e é DESCLASSIFICADO!")],
                                         size=14, color="#D32F2F"), bgcolor="#FFEBEE", padding=10, border_radius=5,
                         border=ft.Border(left=ft.BorderSide(width=4, color="#D32F2F"))),
            ft.Divider(color="#E0E0E0", height=20),
            ft.Text("Mecânica do Tabuleiro", size=16, color="#1A237E", weight="bold"),
            ft.Text(
                "É necessário clicar em “girar o dado” para começar o jogo e a cada nova rodada (o jogador será informado sobre quantas casas andará e deverá clicar em avançar). Aparecerá na tela as opções de escolhas de acordo com a quantidade de casas sorteadas. Após escolher a opção desejada, deve clicar em avançar e será a vez do próximo jogador.\n\nDurante a jornada pelo tabuleiro, o jogador encontrará casas especiais identificadas com o símbolo de exclamação (!), elas representam alguns marcos de vida. Sempre que o jogador passar por uma dessas casas, ele vai poder escolher investir em Previdência Complementar. Estes marcos acontecem aos 16, 20, 30 e 45 anos. Para ajudar no controle dessa escolha, a tela do jogo mostra exatamente o valor que o jogador está investindo na sua Previdência Complementar. Em cada uma dessas paradas, as escolhas feitas impactarão diretamente nas reservas financeiras e no patrimônio acumulado até o final do jogo.",
                size=14, color="#333"),
            ft.Divider(color="#E0E0E0", height=20),
            ft.Text("Informações Importantes", size=16, color="#1A237E", weight="bold"),
            ft.Text(
                "Ao final da partida, o jogador será direcionado para a tela de resultados, onde o conteúdo exibido dependerá do desempenho financeiro mantido ao longo do tabuleiro. Se o jogador conseguir concluir o jogo sem ser desclassificado, a tela apresentará a posição final na partida. Nessa mesma tela, será exibido um resumo detalhado da jornada financeira do jogador, contendo a quantidade de conquistas e emojis acumulados, além do saldo final que restou na conta corrente do jogo. Além disso, a tela também mostra todo o investimento que o jogador fez em previdência complementar, informando o histórico de contribuições, o total investido e o total de rendimentos (juros compostos) ganhos no período, finalizando com a exibição do patrimônio total do jogador, que é a soma do saldo bruto da previdência com o saldo da conta corrente. Esta mesma tela possui o gráfico de evolução, em que são apresentadas as contribuições realizadas de acordo com as idades e rentabilidades. É possível também clicar na opção “Histórico de escolhas” em que são apresentadas as escolhas feitas pelo jogador e os valores gastos ou ganhos. Ao clicar em avançar, o jogador verá a posição dos outros jogadores. Ele deve clicar em classificação geral para conhecer a ordem de classificação.",
                size=14, color="#333"),
            ft.Text("🏆 Resultado da competição:", size=16, color="#1976D2", weight="bold"),
            ft.Text(
                "Quem atingir o maior patrimônio ganha o jogo! Se a estratégia financeira resultou em um saldo negativo, a tela apresentará a informação de que o jogador foi desclassificado por terminar o jogo com a conta corrente no vermelho. Nesse caso, todos os ganhos e investimentos serão usados para o pagamento das dívidas. O gráfico de evolução não terá nenhuma informação, pois todos seus investimentos foram utilizados.",
                size=14, color="#333"),
            ft.Divider(color="#E0E0E0", height=20),
            ft.Text("Observações:", size=16, color="#1A237E", weight="bold"),
            ft.Text(
                "• Ao clicar em classificação geral é possível ver a classificação de cada jogador, patrimônio e emojis conquistados.\n• Ao clicar em finalizar o jogo, é feito o direcionamento para a tela inicial do jogo.",
                size=14, color="#333")
        ], spacing=10, scroll=ft.ScrollMode.AUTO), height=450, padding=ft.Padding(left=0, top=0, right=15, bottom=0)
    )

    card_manual = ft.Container(
        content=ft.Column([
            ft.Text("📖 Manual Completo do Jogo", size=20, weight="900", color="#1A237E", font_family="Georgia"),
            corpo_manual,
            ft.Container(content=ft.ElevatedButton("Entendi!", bgcolor="#FF9800", color="white",
                                                   style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8),
                                                                        padding=15), on_click=fechar_manual),
                         alignment=ft.Alignment(0, 0), margin=ft.Margin(left=0, top=10, right=0, bottom=0))
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, tight=True),
        width=750, bgcolor="white", border_radius=15, padding=30,
        border=ft.Border(top=ft.BorderSide(width=2, color="#1A237E"), bottom=ft.BorderSide(width=2, color="#1A237E"),
                         left=ft.BorderSide(width=2, color="#1A237E"), right=ft.BorderSide(width=2, color="#1A237E")),
        shadow=ft.BoxShadow(blur_radius=20, color="black26")
    )
    wrapper_manual = ft.Container(content=card_manual, alignment=ft.Alignment(0, 0), visible=False)

    tela_regras = ft.Stack([
        ft.Container(content=ft.Image(src="Marisela_pensar.png", height=650, fit="contain"),
                     alignment=ft.Alignment(-1, 1)),
        ft.Container(content=card_regras, alignment=ft.Alignment(0, 0)),
        wrapper_manual
    ], expand=True, visible=False)

    page.add(tela_menu, tela_sorteio, tela_regras, tela_jogo, tela_ranking, tela_resumo)


ft.run(main, view=ft.AppView.WEB_BROWSER, assets_dir="Imagens")